Inputs Directory
================

Place the support bundle tarballs in this folder.  The support bundles may be
grouped into folders (one level deep) which will group them in the report.  This
will cause the support bundles to be labelled and data to be generated for that
group.
