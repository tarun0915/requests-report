Requests Report Tool
====================

This is an updated tool to handle processing of requests logs extracted from support logs bundles available on
`supportlogs.jfrog.com`.

Features
--------

 * Supports multiple support and/or logs bundles.  Accepts multiple log bundles in a nested folder format and
   automatically picks up active and rotated request logs.  It's no longer needed to manual extract and pick out the
   request logs.  Also supports the "artifactory-request" logs being placed directly into the inputs or group folders.

 * Supports multiple support bundle formats:
   * Log Bundles (*.tar.gz) from the support team
   * Artifactory Version 7.* Support Bundles (*.zip)
   * Artifactory Version 7.* Support Bundles using DynaTrace Request Logs (*.zip)
   * Artifactory Version 6.* Support bundles (*.zip)
   * Artifactory Version 7 log files (both .log and .log.gz)

 * De-duplication of logs.  Skips duplicate or redundant archived request log if it is found in multiple support
   bundles.  Helps to avoid skewed (inflated) analysis when the customer generates support bundles every few hours with
   overlapping archived log present in more than one support bundle.

 * Graphs of data.  Plots the transfer aggregate across all nodes (date on X-axis and transfer Bytes on Y-axis) and
   transfer plot per node over days and over hours.  Helps identify the traffic patterns, peak usage days and highly
   busy nodes (all in a single PDF) that can be easily shareable to the Customer, making TCO calculations much easier
   to showcase.

 * Data Summary.  Prints the start and end time stamp, duration of the analysis, and total transfer values.

 * Automatically extrapolates a 1 day, 30 day, and 365 day estimate based on the duration of logs analyzed.

Roadmap
-------

 * Add processing for concurrent requests and request rates.

 * Add lots of calculations:
   * Transfer per day mean average
   * Daily peak requests per minute
   * Daily average requests per minute
   * Daily peak requests over 1, 10, 100, 1000 seconds in duration
   * Daily average requests over 1, 10, 100, 1000 seconds in duration
   * Duration totals for daily requests over 1, 10, 100, 1000 seconds in duration
   * Total number of requests
   * Number of requests per day average
   * Number of requests per hour average
   * Request size metrics

 * Add all of the repo types to the repo types graphs

 * Drop the "summary" graphs is there's only the default group.  Also, don't display the "default" group name.

Installing and Running
----------------------

 1. Make sure Python 3.11 or higher is installed.  If there is an error when running this script about ISO8601
    timestamps, this is likely due to having to low of a Python version.
    ```
    python --version
    ```

 2. Install all of the Python dependencies.  If there is an error about the version of the `kaleido` library not being
    available or if there are issues in generating the graphs (usually on Windows), change the version number in
    `requirements.txt` to `0.1.0.post1` and try again.
    ```
    pip install -r requirements.txt
    ```
    
 3. Place the support log bundles into the `inputs` folder, either directly or under a single level of directories.  Any
    bundles placed directly in the `inputs` directory will be included in a "default" group.  Any bundles placed in
    directories will be placed into a group using the name of the directory.

 4. Run the script:
    ```
    python generate_report.py
    ```
    
    A number of options are available:
     * `--generate_csv` will output CSV files containing all of the data used to create the graphs internally.  This is
       useful for making new graphs or making graphs for a short time window.
     * `--generate_png` will output PNG images similar to, but not exactly the same as, the graphs from the PDF.
     * `--generate_svg` will output SVG images similar to, but not exactly the same as, the graphs from the PDF.
     * `--img_width` will set the width for PNG and SVG images.
     * `--img_height` will set the height for PNG and SVG images.
     * `--only_bad_stuff` will remove some of the date from the graphs that is not considered to be error conditions,
       such as 200 and 201 for https status codes and request times less than one second for slow requests.
     * `--verbose` which enables debug logging.  Warning: This is VERY VERBOSE!
     * `--log_output_file <filename>` which moves the text output of the program into a log file specified by the
       filename.  This is especially useful when using the verbose option.
     * `--output_filename <string>` which uses the string as the start of the filename for output files.  This defaults
       to "output".

Installation Notes
------------------

 * This requires Python 3.11 due to improvements in the datetime class.
 * The `kaleido` line in `requirements.txt` may need to be changed to `kaleido==0.1.0.post1` if running on Windows due
   to issues with the later pre-compiled versions not working correctly (usually freezes).

Inputs Directory
================

Place the support bundle tarballs in this folder.  The support bundles may be
grouped into folders (one level deep) which will group them in the report.  This
will cause the support bundles to be labelled and data to be generated for that
group.

Outputs Directory
=================

The output files will appear in this folder.



Running On Docker
-----------------

When developing the docker container for JFrog pipelines, use the following commands to run the docker container that
pulls a support bundle and runs the requests-report script:
```
export USER=<USER>
export TOKEN=<TOKEN>

export DOWNLOAD_PATH=https://<HOST>/artifactory/<REPO>/<ARTIFACT>

Example:

UPLOAD_PATH="https://solengcustomersupport.jfrog.io/artifactory/customer-support-bundles-results/outputs/"


./run-docker.sh
```
