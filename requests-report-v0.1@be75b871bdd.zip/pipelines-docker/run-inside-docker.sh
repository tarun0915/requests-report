#!/bin/bash

echo $JSON
FILE_PATH = $(echo "$JSON" | jq '.data.path')
echo $FILE_PATH

DOWNLOAD_PATH=$BASE_URL$FILE_PATH
echo $DOWNLOAD_PATH

OUTPUT_FILE="${DOWNLOAD_PATH##*/}"_output
echo $OUTPUT_FILE

mkdir -p /app/inputs
cd /app/inputs
curl -L -u $USER:$TOKEN -O "${DOWNLOAD_PATH}"

cd /app
ls -lrt 

python3 generate_report.py --output_filename $OUTPUT_FILE

curl -u $USER:$TOKEN -T ./outputs/* $UPLOAD_PATH

