#!/bin/bash

DOWNLOAD_REPO=$(echo "${res_IncomingWebhookResource_payload}" | jq '.data.repo_key' | tr -d '"')
DOWNLOAD_PATH=$(echo "${res_IncomingWebhookResource_payload}" | jq '.data.path' | tr -d '"')
DOWNLOAD_URL=${int_artifactory_pipelines_user_url}/artifactory/${DOWNLOAD_REPO}/${DOWNLOAD_PATH}

#echo ${res_IncomingWebhookResource_payload}
#echo ${DOWNLOAD_PATH}
echo ${DOWNLOAD_URL}

# Check if the DOWNLOAD_PATH ends with '.zip'
if [[ ${DOWNLOAD_PATH} == *.zip ]]
then
  echo "ZIP File, likely Support Bundle, downloading."
  curl -L -H"Authorization: Bearer ${int_artifactory_pipelines_user_accessToken}" -O "${DOWNLOAD_URL}"
else
  echo "Not a ZIP File, skipping."
fi
