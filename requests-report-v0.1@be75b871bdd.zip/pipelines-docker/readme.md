Pipelines Docker Image
======================

The contents of this folder are used to build a custom image for use in a JFrog
Pipelines pipeline.

Building the Image
------------------

In order to build the image for use in JFrog Pipelines, run the following
command from the folder containing the project (e.g. the folder containing the
inputs and outputs folder):

```
docker build --progress=plain --no-cache -f pipelines-docker/Dockerfile -t <IMAGE>:<TAG> .
```


Using Image in Pipeline
-----------------------

In order to use the image in a pipeline, the following sections have to be
included in the pipelines YAML files:

 * Resources:
```

```

 * Values:
```

```

 * Steps:
```

```
