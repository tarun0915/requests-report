#!/usr/bin/env python3

### IMPORTS ###
import argparse
import datetime
import logging
import os
import sys

from reqrep import BundleWalker, InputsWalker, TransferCalc, RequestsCalc, SlowCalc, TrafficTypesCalc, StatusCodeCalc
from reqrep.pdfgen import PDFGen

### GLOBALS ###
LINE_COUNT = 0

### FUNCTIONS ###
def debug_printer(value):
    logging.debug("DEBUG PRINTER: %s", value)

def debug_null(value):
    pass

def debug_counter(value):
    global LINE_COUNT
    LINE_COUNT = LINE_COUNT + 1

### CLASSES ###

### MAIN ###
def main():
    # Parser
    parser = argparse.ArgumentParser(description = "Generate report from request logs in support bundles.")
    parser.add_argument("-v", "--verbose", action = "store_true")
    parser.add_argument("--log_output_file", help = "File to output logging.")
    parser.add_argument("--output_filename", default = "output", help = "Name for output files.")
    parser.add_argument("--only_bad_stuff", action = "store_true", help = "Don't show happy path results in the graphs.")
    parser.add_argument("--generate_csv", action = "store_true", help = "Generate CSV files with the data for the graphs.")
    parser.add_argument("--generate_svg", action = "store_true", help = "Generate SVG images of the graphs from the PDF.")
    parser.add_argument("--generate_png", action = "store_true", help = "Generate PNG images of the graphs from the PDF.")
    parser.add_argument("--img_width", type = int, default = 1920, help = "Width of images when generating the PNG and SVG images.")
    parser.add_argument("--img_height", type = int, default = 1080, help = "Width of images when generating the PNG and SVG images.")
    args = parser.parse_args()

    # Logging
    log_format = "%(asctime)s:%(levelname)s:%(name)s.%(funcName)s: %(message)s"
    log_root = logging.getLogger()
    log_root.setLevel(logging.DEBUG if args.verbose else logging.INFO)
    log_handler = None
    if args.log_output_file:
        log_handler = logging.FileHandler(args.log_output_file, 'w', 'utf-8')
    else:
        log_handler = logging.StreamHandler(sys.stdout)
    log_handler.setLevel(logging.DEBUG if args.verbose else logging.INFO)
    log_handler.setFormatter(logging.Formatter(log_format))
    log_root.addHandler(log_handler)

    # Environment
    logging.debug("Args: %s", args)

    # Remove the contents of the output directory
    # FIXME: This should use a command line argument for the output folder.
    for filename in os.listdir('outputs'):
        if filename[-4:] in ['.csv', '.pdf', '.png', '.svg', '.zip']:
            file_path = os.path.join('outputs', filename)
            logging.debug("Removing file: %s", file_path)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)
            except Exception as e:
                # Something's wrong with the file system...
                logging.error('Failed to delete %s. Reason: %s' % (file_path, e))
                sys.exit(1)

    # Get start time
    start_time = datetime.datetime.now()
    logging.debug("Starting at: %s", start_time.isoformat())

    # Parse through support bundles
    # Extract request logs into data structure
    iw = InputsWalker("./inputs")

    tc = TransferCalc()
    rc = RequestsCalc()
    sc = SlowCalc()
    ttc = TrafficTypesCalc()
    scc = StatusCodeCalc()

    for group_name in iw.groups:
        bw = BundleWalker(filededup = True)
        bw.add_callback(debug_counter)
        bw.add_callback(tc.add_log_entry)
        bw.add_callback(rc.add_log_entry)
        bw.add_callback(sc.add_log_entry)
        bw.add_callback(ttc.add_log_entry)
        bw.add_callback(scc.add_log_entry)

        for bundle in iw.bundles[group_name]:
            bw.walk_bundle(bundle)

    # Get bundle walk time
    bundle_time = datetime.datetime.now()
    logging.debug("Bundle walking complete at: %s", bundle_time.isoformat())

    # Check to see if any data was imported.
    if rc.request_counts["total"] < 1:
        logging.error("No requests logs we imported.  Check input files.")
        raise Exception("NO REQUESTS LOG ENTRIES")

    # Generate "Transfer" report data
    logging.debug("Transfer Totals: down: %d, up: %d", tc.total_down, tc.total_up)
    logging.debug("Transfer By Day: %s", tc.by_day)
    logging.debug("Transfer By Group By Day: %s", tc.by_group_by_day)

    # Generate "Requests" report data
    logging.debug("Request Total: %s", rc.request_counts)
    logging.debug("Request minute count: %d", len(rc.minute_counts))
    logging.debug("Request minute: %s", rc.minute_counts)

    # Generate "Slow" report data
    logging.debug("Slow Total: %d", sc.rle_count)
    logging.debug("Slow Counts: %s", sc.get_slow_counts())

    # Generate "TrafficTypes" report data
    logging.debug("TrafficTypes Total: %d", ttc.rle_count)
    logging.debug("TrafficTypes Counts: %s", ttc.get_counts())

    # Generate "StatusCodes" report data
    logging.debug("StatusCodes Total: %d", scc.rle_count)
    logging.debug("StatusCodes Counts: %s", scc.get_counts())

    # Generate report
    logging.debug("Total lines processed: %d", LINE_COUNT)
    rc.get_stats()

    pg = PDFGen(
        filename = "outputs/{}.pdf".format(args.output_filename),
        only_bad_stuff = args.only_bad_stuff,
        groups = iw.groups,
        tc = tc,
        rc = rc,
        sc = sc,
        ttc = ttc,
        scc = scc,
        gencsv = args.generate_csv,
        genpng = args.generate_png,
        gensvg = args.generate_svg,
        img_width = args.img_width,
        img_height = args.img_height,
        output_filename = args.output_filename
    )

    # Get end time
    end_time = datetime.datetime.now()
    logging.debug("PDF Generation done at: %s", end_time.isoformat())

    # Calculate times for bundle walk, PDF Gen, and total
    logging.debug("Bundle Walking time: %s", (bundle_time - start_time))
    logging.debug("PDF Generation time: %s", (end_time - bundle_time))
    logging.info("Total script run time: %s", (end_time - start_time))

if __name__ == "__main__":
    main()
