#!/usr/bin/env python3

### IMPORTS ###
import logging
import os

from .bundle import Bundle, BundleType

### GLOBALS ###

### FUNCTIONS ###

### CLASSES ###
class InputsWalker:
    def __init__(self, inputs_path):
        self.logger = logging.getLogger(type(self).__name__)
        self.inputs_path = inputs_path
        self.bundles = {}
        self.groups = []
        # ...
        self._walk_inputs()

    def _walk_inputs(self):
        self.logger.debug("Walking inputs path: %s", self.inputs_path)
        with os.scandir(self.inputs_path) as it1:
            for entry in it1:
                # If the file name ends with ".tar.gz", add it to the bundle list.
                self.logger.debug("  Entry name: %s, is_file: %s, is_dir: %s", entry.name, entry.is_file(), entry.is_dir())

                if entry.is_file():
                    if entry.name[-7:] == ".tar.gz":
                        # Add logs tarball bundle that is in the inputs folder (no group)
                        self.logger.debug("  Adding to bundle list with group: default")
                        if "default" not in self.groups:
                            self.groups.append("default")
                            self.bundles["default"] = []
                        self.bundles["default"].append(Bundle("default", entry.name, type = BundleType.TARBALL))

                    elif entry.name[-4:] == ".zip":
                        # Add support bundle that is in the inputs folder (no group)
                        self.logger.debug("  Adding to bundle list with group: default")
                        if "default" not in self.groups:
                            self.groups.append("default")
                            self.bundles["default"] = []
                        self.bundles["default"].append(Bundle("default", entry.name, type = BundleType.SUPPORT))

                    elif entry.name[-4:] == ".log":
                        # Add raw log that is in the inputs folder (no group)
                        self.logger.debug("  Adding to bundle list with group: default")
                        if "default" not in self.groups:
                            self.groups.append("default")
                            self.bundles["default"] = []
                        self.bundles["default"].append(Bundle("default", entry.name, type = BundleType.LOG))

                    elif entry.name[-7:] == ".log.gz":
                        # Add gzip'd log that is in the inputs folder (no group)
                        self.logger.debug("  Adding to bundle list with group: default")
                        if "default" not in self.groups:
                            self.groups.append("default")
                            self.bundles["default"] = []
                        self.bundles["default"].append(Bundle("default", entry.name, type = BundleType.LOGGZ))

                elif entry.is_dir():
                    group_name = entry.name
                    if group_name not in self.groups:
                        self.groups.append(group_name)
                        self.bundles[group_name] = []
                    with os.scandir(os.path.join(self.inputs_path, entry.name)) as it2:
                        for entry2 in it2:
                            # If the file name ends with ".tar.gz", add it to the bundle list.
                            self.logger.debug("  Entry name: %s, is_file: %s, is_dir: %s", entry2.name, entry2.is_file(), entry2.is_dir())

                            if entry2.is_file() and entry2.name[-7:] == ".tar.gz":
                                # Add logs tarball bundle that is in a group folder
                                self.logger.debug("  Adding to bundle list with group: %s", group_name)
                                self.bundles[group_name].append(Bundle(group_name, entry2.name, type = BundleType.TARBALL))

                            elif entry2.is_file() and entry2.name[-4:] == ".zip":
                                # Add support bundle that is in a group folder
                                self.logger.debug("  Adding to bundle list with group: %s", group_name)
                                self.bundles[group_name].append(Bundle(group_name, entry2.name, type = BundleType.SUPPORT))

                            elif entry2.is_file() and entry2.name[-4:] == ".log":
                                # Add raw log that is in a group folder
                                self.logger.debug("  Adding to bundle list with group: %s", group_name)
                                self.bundles[group_name].append(Bundle(group_name, entry2.name, type = BundleType.LOG))

                            elif entry2.is_file() and entry2.name[-7:] == ".log.gz":
                                # Add gzip'd log that is in a group folder
                                self.logger.debug("  Adding to bundle list with group: %s", group_name)
                                self.bundles[group_name].append(Bundle(group_name, entry2.name, type = BundleType.LOGGZ))
