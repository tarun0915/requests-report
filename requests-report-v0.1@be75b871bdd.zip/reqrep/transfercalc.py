#!/usr/bin/env python3

### IMPORTS ###
import datetime
import logging

from .exceptions import InvalidGroupException

### GLOBALS ###

### FUNCTIONS ###

### CLASSES ###
class TransferCalc:
    def __init__(self):
        self.logger = logging.getLogger(type(self).__name__)
        self.total_down = 0
        self.total_up = 0
        self.ts_first = None
        self.ts_last = None
        self.groups = []
        self.by_group_total = {}
        self.by_day = {}
        self.by_hour = {}
        self.by_group_by_day = {}
        self.by_group_by_hour = {}

    def add_log_entry(self, rle):
        # Check dates
        if self.ts_first is None or rle.timestamp < self.ts_first:
            self.ts_first = rle.timestamp
        if self.ts_last is None or rle.timestamp > self.ts_last:
            self.ts_last = rle.timestamp
        # add to totals
        self.total_down = self.total_down + rle.down_size
        self.total_up = self.total_up + rle.up_size
        # add to possible groups list
        if rle.group not in self.groups:
            self.groups.append(rle.group)
        # add to totals for group
        if rle.group not in self.by_group_total:
            self.by_group_total[rle.group] = {"down": 0, "up": 0, "first": None, "last": None}
        if self.by_group_total[rle.group]["first"] is None or rle.timestamp < self.by_group_total[rle.group]["first"]:
            self.by_group_total[rle.group]["first"] = rle.timestamp
        if self.by_group_total[rle.group]["last"] is None or rle.timestamp > self.by_group_total[rle.group]["last"]:
            self.by_group_total[rle.group]["last"] = rle.timestamp
        self.by_group_total[rle.group]["down"] = self.by_group_total[rle.group]["down"] + rle.down_size
        self.by_group_total[rle.group]["up"] = self.by_group_total[rle.group]["up"] + rle.up_size
        # figure out day and add to day
        date_str = rle.timestamp.strftime('%Y-%m-%d')
        if rle.group not in self.by_group_by_day:
            self.by_group_by_day[rle.group] = {}
        if date_str not in self.by_group_by_day[rle.group]:
            self.by_group_by_day[rle.group][date_str] = {"down": 0, "up": 0}
        if date_str not in self.by_day:
            self.by_day[date_str] = {"down": 0, "up": 0}
        self.by_day[date_str]["down"] = self.by_day[date_str]["down"] + rle.down_size
        self.by_day[date_str]["up"] = self.by_day[date_str]["up"] + rle.up_size
        self.by_group_by_day[rle.group][date_str]["down"] = self.by_group_by_day[rle.group][date_str]["down"] + rle.down_size
        self.by_group_by_day[rle.group][date_str]["up"] = self.by_group_by_day[rle.group][date_str]["up"] + rle.up_size
        # figure out hour and add to hour
        hour_str = rle.timestamp.strftime('%Y-%m-%d %H:00')
        if rle.group not in self.by_group_by_hour:
            self.by_group_by_hour[rle.group] = {}
        if hour_str not in self.by_group_by_hour[rle.group]:
            self.by_group_by_hour[rle.group][hour_str] = {"down": 0, "up": 0}
        if hour_str not in self.by_hour:
            self.by_hour[hour_str] = {"down": 0, "up": 0}
        self.by_hour[hour_str]["down"] = self.by_hour[hour_str]["down"] + rle.down_size
        self.by_hour[hour_str]["up"] = self.by_hour[hour_str]["up"] + rle.up_size
        self.by_group_by_hour[rle.group][hour_str]["down"] = self.by_group_by_hour[rle.group][hour_str]["down"] + rle.down_size
        self.by_group_by_hour[rle.group][hour_str]["up"] = self.by_group_by_hour[rle.group][hour_str]["up"] + rle.up_size

    def duration(self, group = None):
        if group is None:
            return self.ts_last - self.ts_first
        return self.by_group_total[group]["last"] - self.by_group_total[group]["first"]

    def duration_str(self, group = None):
        tdelta = self.duration(group)
        tstr = ""
        if tdelta.days > 0:
            tstr = "{} Days, {} hours, {} minutes, {} seconds".format(
                int(tdelta.days),
                int(tdelta.seconds / 3600),
                int((tdelta.seconds % 3600) / 60),
                int(tdelta.seconds % 60)
            )
        else:
            tstr = "{} hours, {} minutes, {} seconds".format(
                int(tdelta.seconds / 3600),
                int((tdelta.seconds % 3600) / 60),
                int(tdelta.seconds % 60)
            )
        return tstr

    def mean_avg_per_sec(self, group):
        # There should always be a group specified, so check if it's in the list of groups
        if group not in self.groups:
            # FIXME: Raise Exception
            self.logger.error("Requesting mean average for invalid group: %s", group)
            raise InvalidGroupException()
        tdelta = self.duration(group)
        if tdelta.total_seconds() < 1:
            # FIXME: Handle this with exceptions in the future
            self.logger.warning("Duration is zero or not valid, must be lacking data.")
            return {"up": 0, "down": 0}
        ttup = self.by_group_total[group]["up"]
        ttdown = self.by_group_total[group]["down"]
        result = {
            "up": int(ttup / tdelta.total_seconds()),
            "down": int(ttdown / tdelta.total_seconds())
        }
        self.logger.debug(
            "Mean Average per sec [%s]: %s, ttup: %d B, ttdown: %d B, tdelta_sec: %d",
            str(group),
            result,
            ttup,
            ttdown,
            tdelta.total_seconds()
        )
        return result

    def mean_avg_per_days(self, group = None, days = 1):
        groups = []
        if group is None:
            groups = self.groups
        else:
            groups.append(group)
        result = {
            "up": int(0),
            "down": int(0)
        }
        for tmp_group in groups:
            tmp_result = self.mean_avg_per_sec(tmp_group)
            result["up"] = result["up"] + int(tmp_result["up"] * 3600 * 24 * days)
            result["down"] = result["down"] + int(tmp_result["down"] * 3600 * 24 * days)
        self.logger.debug("Mean Average per %d days [%s]: %s", days, str(groups), result)
        return result

    # # FIXME: These mean_avg_per_* methods could be combine with the "per" option made into an argument from a list.
    # #        Or could combine these into a single method that just puts out all three in a dict...
    # def mean_avg_per_day(self, group = None):
    #     tdelta = self.duration(group)
    #     if tdelta.total_seconds() < 1:
    #         # FIXME: Handle this with exceptions in the future
    #         self.logger.warning("Duration is zero or not valid, must be lacking data.")
    #         return {"up": 0, "down": 0}
    #     ttup = self.total_up if group is None else self.by_group_total[group]["up"]
    #     ttdown = self.total_down if group is None else self.by_group_total[group]["down"]
    #     # num_secs_in_day = 3600 secs in an hour * 24 hours in a day = 86400
    #     # mean_avg = num_secs_in_day * ( transfer_total / duration_in_seconds )
    #     result = {
    #         "up": int((3600 * 24) * (ttup / tdelta.total_seconds())),
    #         "down": int((3600 * 24) * (ttdown / tdelta.total_seconds()))
    #     }
    #     self.logger.debug(
    #         "Mean Average [%s]: %s, ttup: %d B, ttdown: %d B, tdelta_sec: %d",
    #         str(group),
    #         result,
    #         ttup,
    #         ttdown,
    #         tdelta.total_seconds()
    #     )
    #     return result
    #
    # def mean_avg_per_month(self, group = None):
    #     tdelta = self.duration(group)
    #     if tdelta.total_seconds() < 1:
    #         # FIXME: Handle this with exceptions in the future
    #         self.logger.warning("Duration is zero or not valid, must be lacking data.")
    #         return {"up": 0, "down": 0}
    #     ttup = self.total_up if group is None else self.by_group_total[group]["up"]
    #     ttdown = self.total_down if group is None else self.by_group_total[group]["down"]
    #     # num_secs_in_month = 3600 secs in an hour * 24 hours in a day * 30 days in a month
    #     # mean_avg = num_secs_in_day * ( transfer_total / duration_in_seconds )
    #     result = {
    #         "up": int((3600 * 24 * 30) * (ttup / tdelta.total_seconds())),
    #         "down": int((3600 * 24 * 30) * (ttdown / tdelta.total_seconds()))
    #     }
    #     self.logger.debug(
    #         "Mean Average [%s]: %s, ttup: %d B, ttdown: %d B, tdelta_sec: %d",
    #         str(group),
    #         result,
    #         ttup,
    #         ttdown,
    #         tdelta.total_seconds()
    #     )
    #     return result
    #
    # def mean_avg_per_year(self, group = None):
    #     # FIXME: If there is no group specific, this should sum the results from all of the groups, not calculate based on all of the available data.
    #     if group is not None:
    #         tdelta = self.duration(group)
    #         if tdelta.total_seconds() < 1:
    #             # FIXME: Handle this with exceptions in the future
    #             self.logger.warning("Duration is zero or not valid, must be lacking data.")
    #             return {"up": 0, "down": 0}
    #         ttup = self.total_up if group is None else self.by_group_total[group]["up"]
    #         ttdown = self.total_down if group is None else self.by_group_total[group]["down"]
    #         # num_secs_in_year = 3600 secs in an hour * 24 hours in a day * 365 days in a year
    #         # mean_avg = num_secs_in_day * ( transfer_total / duration_in_seconds )
    #         result = {
    #             "up": int((3600 * 24 * 365) * (ttup / tdelta.total_seconds())),
    #             "down": int((3600 * 24 * 365) * (ttdown / tdelta.total_seconds()))
    #         }
    #         self.logger.debug(
    #             "Mean Average [%s]: %s, ttup: %d B, ttdown: %d B, tdelta_sec: %d",
    #             str(group),
    #             result,
    #             ttup,
    #             ttdown,
    #             tdelta.total_seconds()
    #         )
    #     return result
