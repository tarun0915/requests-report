#!/usr/bin/env python3

### IMPORTS ###
from reportlab.platypus import TableStyle
from reportlab.platypus.tableofcontents import delta
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors

### GLOBALS ###
PAGE_TYPE = letter

PAGE_MARGIN_LEFT = 0.5 * inch

FRAME_WIDTH = (8.5 * inch) - 2 * PAGE_MARGIN_LEFT # 7.8 * inch
FRAME_HEIGHT = 4.4444 * inch

STYLE_H1 = ParagraphStyle(name = "Heading1", fontSize = 14, leading = 16)
STYLE_H2 = ParagraphStyle(name = "Heading2", fontSize = 12, leading = 14)

STYLE_H1TOC = ParagraphStyle(name = "Heading1TOC", fontSize = 14, leading = 16)
STYLE_H2TOC = ParagraphStyle(name = "Heading2TOC", fontSize = 12, leading = 14, leftIndent = delta)

STYLE_TABLE_SUMMARY = TableStyle([
    ("FONTFACE", (0, 0), (-1, -1), "Helvetica"),
    ("FONTSIZE", (0, 0), (-1, -1), 14),
    #("LINEBEFORE", (1, 0), (1, -1), 1.0, colors.black),
    ("ALIGN", (0, 0), (0, -1), "RIGHT"),
    ("ALIGN", (1, 0), (1, -1), "LEFT")
])

COLOR_PASTEL_RED = "#fd7f6f"
COLOR_PASTEL_BLUE = "#7eb0d5"
COLOR_PASTEL_GREEN = "#b2e061"
COLOR_PASTEL_PURPLE = "#bd7ebe"
COLOR_PASTEL_ORANGE = "#ffb55a"
COLOR_PASTEL_YELLOW = "#ffee65"
COLOR_PASTEL_GRAY = "#beb9db"
COLOR_PASTEL_PINK = "#fdcce5"
COLOR_PASTEL_TEAL = "#8bd3c7"

COLOR_DOWNLOAD = COLOR_PASTEL_GREEN
COLOR_UPLOAD = COLOR_PASTEL_BLUE

GRAPH_COLORS = [
    COLOR_PASTEL_BLUE,
    COLOR_PASTEL_GREEN,
    COLOR_PASTEL_PURPLE,
    COLOR_PASTEL_ORANGE,
    COLOR_PASTEL_YELLOW,
    COLOR_PASTEL_GRAY,
    COLOR_PASTEL_PINK,
    COLOR_PASTEL_TEAL,
    COLOR_PASTEL_RED
]

### FUNCTIONS ###

### CLASSES ###
