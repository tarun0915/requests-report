#!/usr/bin/env python3

### IMPORTS ###
from reportlab.platypus import BaseDocTemplate

### GLOBALS ###

### FUNCTIONS ###

### CLASSES ###
class RequestReportDocumentTemplate(BaseDocTemplate):
    def __init__(self, filename, **kw):
        super().__init__(filename, **kw)
        self.allowSplitting = 0
        self.group_name = None

    def afterFlowable(self, flowable):
        # Registers TOC entries
        if flowable.__class__.__name__ == "Paragraph":
            text = flowable.getPlainText()
            style = flowable.style.name
            if style == "Heading1":
                self.notify("TOCEntry", (0, text, self.page))
            if style == "Heading2":
                self.notify("TOCEntry", (1, text, self.page))
