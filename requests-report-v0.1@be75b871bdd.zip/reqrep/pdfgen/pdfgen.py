#!/usr/bin/env python3

### IMPORTS ###
import io
import logging

import plotly.graph_objects
import plotly.io

from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas

from reportlab.platypus import NextPageTemplate, PageBreak, Table, Image
from reportlab.platypus.tableofcontents import TableOfContents

from reqrep.numconv import NumConv

from .requestreportdocumenttemplate import RequestReportDocumentTemplate
from .summarypagetemplate import gen_summary_page_template
from .grouppagetemplate import gen_group_page_template

from .graphs import *
from .styles import *

from ..csvgen import genCSV

### GLOBALS ###

### FUNCTIONS ###

### CLASSES ###
class PDFGen:
    def __init__(self, filename, only_bad_stuff, groups, tc, rc, sc, ttc, scc, gencsv = False, genpng = False, gensvg = False, img_width = 0, img_height = 0, output_filename = "output"):
        self.logger = logging.getLogger(type(self).__name__)
        self.only_bad_stuff = only_bad_stuff
        self.groups = groups
        self.tc = tc # TransferCalc
        self.rc = rc # RequestCalc
        self.sc = sc # SlowCalc
        self.ttc = ttc # TrafficTypesCalc
        self.scc = scc # StatusCodeCalc

        # FIXME: This should be handled separately, but doing here due to reusing graph data
        self.gencsv = gencsv
        self.genpng = genpng
        self.gensvg = gensvg

        self.output_filename = output_filename
        self.img_width = img_width
        self.img_height = img_height
        plotly.io.kaleido.scope.default_width = self.img_width
        plotly.io.kaleido.scope.default_height = self.img_height
        plotly.io.kaleido.scope.default_scale = 1

        self.doc = RequestReportDocumentTemplate(filename) # NOTE: This has to exist for the group pages to work correctly.

        summary_page_template = gen_summary_page_template()
        self.doc.addPageTemplates(summary_page_template)

        for group_name in groups:
            group_page_template = gen_group_page_template(group_name)
            self.doc.addPageTemplates(group_page_template)

        self.story = []
        self.toc = TableOfContents()
        self.toc.levelStyles = [STYLE_H1TOC, STYLE_H2TOC]

        # FIXME: Not sure a TOC is necessary here
        #story.append(toc)
        #story.append(PageBreak())

        # FIXME: Is a heading valid here?  Not sure it's really useful.
        #        How do we change the title on the group pages?
        #story.append(Paragraph("First Heading", h1))

        # FIXME: Is Paragraph to be used for tables and graphs?
        #story.append(Paragraph("Text in the first heading", ParagraphStyle("body")))

        self.story.append(NextPageTemplate("summary_page"))
        self._add_summary()
        # NOTE: PageBreak has to happen after the template change to apply to the next page.
        #if len(groups.keys()) > 1:
        for group_name in groups:
            self.story.append(NextPageTemplate("group_page - {}".format(group_name)))
            self.story.append(PageBreak())
            self._add_group(group_name)

        self.doc.multiBuild(self.story)

    def _calc_dtick(self, group_name = None):
        tp_dur = self.tc.duration(group_name)
        dtick = 86400000.0
        if tp_dur.days < 3:
            dtick = 14400000.0
        if tp_dur.days == 0:
            dtick = 3600000.0
            if (tp_dur.seconds / 3600) < 6:
                dtick = 600000.0
            if (tp_dur.seconds / 3600) < 3:
                dtick = 300000.0
            if (tp_dur.seconds / 3600) == 0:
                dtick = 60000.0
        return dtick

    def _summary_table(self):
        # Table with summary numbers
        t_down = NumConv(self.tc.total_down)
        t_up = NumConv(self.tc.total_up)
        ttpd = self.tc.mean_avg_per_days(days = 1)
        ttpd_down = NumConv(ttpd["down"])
        ttpd_up = NumConv(ttpd["up"])
        ttpm = self.tc.mean_avg_per_days(days = 30)
        ttpm_down = NumConv(ttpm["down"])
        ttpm_up = NumConv(ttpm["up"])
        ttpy = self.tc.mean_avg_per_days(days = 365)
        ttpy_down = NumConv(ttpy["down"])
        ttpy_up = NumConv(ttpy["up"])
        rpm_total_avg = self.rc.request_counts["total"] / len(self.rc.minute_counts)
        rpm_slow_avg = (self.sc.slow_counts["10 - 99 sec"] + self.sc.slow_counts["100 - 999 sec"] + self.sc.slow_counts["1000+ sec"]) / len(self.sc.slow_counts_by_minute)
        data = [
            ["First Date:", self.tc.ts_first.strftime('%Y-%m-%d %H:%M')],
            ["Last Date:", self.tc.ts_last.strftime('%Y-%m-%d %H:%M')],
            ["Time Span:", self.tc.duration_str()],
            ["Transfer Total Down:", "{}B ( {}B )".format(t_down.number_prefix, t_down.number_prefix_i)],
            ["Transfer Total Up:", "{}B ( {}B )".format(t_up.number_prefix, t_up.number_prefix_i)],
            ["Summed Transfer Average per day Down:", "{}B ( {}B )".format(ttpd_down.number_prefix, ttpd_down.number_prefix_i)],
            ["Summed Transfer Average per day Up:", "{}B ( {}B )".format(ttpd_up.number_prefix, ttpd_up.number_prefix_i)],
            ["Summed Transfer Average per month Down:", "{}B ( {}B )".format(ttpm_down.number_prefix, ttpm_down.number_prefix_i)],
            ["Summed Transfer Average per month Up:", "{}B ( {}B )".format(ttpm_up.number_prefix, ttpm_up.number_prefix_i)],
            ["Summed Transfer Average per year Down:", "{}B ( {}B )".format(ttpy_down.number_prefix, ttpy_down.number_prefix_i)],
            ["Summed Transfer Average per year Up:", "{}B ( {}B )".format(ttpy_up.number_prefix, ttpy_up.number_prefix_i)],
            ["Average Requests per Minute:", "{}".format(int(rpm_total_avg))],
            ["Average Slow Requests per Minute:", "{}".format(int(rpm_slow_avg))],
            ["Average Percentage Slow Requests per Minute:", "{}%".format(round(rpm_slow_avg / rpm_total_avg, 3) * 100)]
        ]
        # FIXME: Add status code counts
        return Table(data, style = STYLE_TABLE_SUMMARY)

    def _group_table(self, group_name):
        # Table with summary numbers
        t_down = NumConv(self.tc.by_group_total[group_name]["down"])
        t_up = NumConv(self.tc.by_group_total[group_name]["up"])
        ttpd = self.tc.mean_avg_per_days(group_name, 1)
        ttpd_down = NumConv(ttpd["down"])
        ttpd_up = NumConv(ttpd["up"])
        ttpm = self.tc.mean_avg_per_days(group_name, 30)
        ttpm_down = NumConv(ttpm["down"])
        ttpm_up = NumConv(ttpm["up"])
        ttpy = self.tc.mean_avg_per_days(group_name, 365)
        ttpy_down = NumConv(ttpy["down"])
        ttpy_up = NumConv(ttpy["up"])
        ttpd_short = self.tc.mean_avg_per_days(group_name, 1 * 10/24)
        ttpd_short_down = NumConv(ttpd_short["down"])
        ttpd_short_up = NumConv(ttpd_short["up"])
        ttpm_short = self.tc.mean_avg_per_days(group_name, 30 * 5/7 * 10/24)
        ttpm_short_down = NumConv(ttpm_short["down"])
        ttpm_short_up = NumConv(ttpm_short["up"])
        ttpy_short = self.tc.mean_avg_per_days(group_name, 365 * 5/7 * 10/24)
        ttpy_short_down = NumConv(ttpy_short["down"])
        ttpy_short_up = NumConv(ttpy_short["up"])
        data = [
            ["First Date:", self.tc.by_group_total[group_name]["first"].strftime('%Y-%m-%d %H:%M')],
            ["Last Date:", self.tc.by_group_total[group_name]["last"].strftime('%Y-%m-%d %H:%M')],
            ["Time Span:", self.tc.duration_str(group_name)],
            ["Transfer Down:", "{}B ( {}B )".format(t_down.number_prefix, t_down.number_prefix_i)],
            ["Transfer Up:", "{}B ( {}B )".format(t_up.number_prefix, t_up.number_prefix_i)],
            ["Transfer Average per day Down:", "{}B ( {}B )".format(ttpd_down.number_prefix, ttpd_down.number_prefix_i)],
            ["Transfer Average per day Up:", "{}B ( {}B )".format(ttpd_up.number_prefix, ttpd_up.number_prefix_i)],
            ["Transfer Average per month Down:", "{}B ( {}B )".format(ttpm_down.number_prefix, ttpm_down.number_prefix_i)],
            ["Transfer Average per month Up:", "{}B ( {}B )".format(ttpm_up.number_prefix, ttpm_up.number_prefix_i)],
            ["Transfer Average per year Down:", "{}B ( {}B )".format(ttpy_down.number_prefix, ttpy_down.number_prefix_i)],
            ["Transfer Average per year Up:", "{}B ( {}B )".format(ttpy_up.number_prefix, ttpy_up.number_prefix_i)],
            ["Business Hours Estimate Transfer Average per day Down:", "{}B ( {}B )".format(ttpd_short_down.number_prefix, ttpd_short_down.number_prefix_i)],
            ["Business Hours Estimate Transfer Average per day Up:", "{}B ( {}B )".format(ttpd_short_up.number_prefix, ttpd_short_up.number_prefix_i)],
            ["Business Hours Estimate Transfer Average per month Down:", "{}B ( {}B )".format(ttpm_short_down.number_prefix, ttpm_short_down.number_prefix_i)],
            ["Business Hours Estimate Transfer Average per month Up:", "{}B ( {}B )".format(ttpm_short_up.number_prefix, ttpm_short_up.number_prefix_i)],
            ["Business Hours Estimate Transfer Average per year Down:", "{}B ( {}B )".format(ttpy_short_down.number_prefix, ttpy_short_down.number_prefix_i)],
            ["Business Hours Estimate Transfer Average per year Up:", "{}B ( {}B )".format(ttpy_short_up.number_prefix, ttpy_short_up.number_prefix_i)]
        ]
        # FIXME: Add status code counts
        return Table(data, style = STYLE_TABLE_SUMMARY)

    def _summary_transfer_by_day(self):
        # Total Transfer by Day
        sorted_by_day = dict(sorted(self.tc.by_day.items()))
        self.logger.debug("sorted_by_day: %s", sorted_by_day)
        day_axis = list(sorted_by_day.keys())
        data = {
            "axis": day_axis,
            "down": [sorted_by_day[i]["down"] for i in day_axis],
            "up": [sorted_by_day[i]["up"] for i in day_axis]
        }
        tcbd = gen_graph_transfer_by_tick(
            data = data,
            dtick = self._calc_dtick(),
            title = "Total transfer by Day",
            linewidth = 2.0,
            colors = [COLOR_DOWNLOAD, COLOR_UPLOAD]
        )
        if self.gencsv:
            genCSV("outputs/{}_total_transfer_by_day.csv".format(self.output_filename), data)
        if self.genpng:
            tcbd.write_image("outputs/{}_total_transfer_by_day.png".format(self.output_filename))
        if self.gensvg:
            tcbd.write_image("outputs/{}_total_transfer_by_day.svg".format(self.output_filename))
        tcbd_for_pdf = tcbd.to_image(format = "png", width = FRAME_WIDTH * 3, height = FRAME_HEIGHT * 3, scale = 1)
        return Image(io.BytesIO(tcbd_for_pdf), FRAME_WIDTH, FRAME_HEIGHT)


    def _summary_transfer_by_hour(self):
        # Total Transfer by Hour
        sorted_by_hour = dict(sorted(self.tc.by_hour.items()))
        self.logger.debug("sorted_by_hour: %s", sorted_by_hour)
        hour_axis = list(sorted_by_hour.keys())
        data = {
            "axis": hour_axis,
            "down": [sorted_by_hour[i]["down"] for i in hour_axis],
            "up": [sorted_by_hour[i]["up"] for i in hour_axis]
        }
        tcbh = gen_graph_transfer_by_tick(
            data = data,
            dtick = self._calc_dtick(),
            title = "Total Transfer by Hour",
            linewidth = 2.0,
            colors = [COLOR_DOWNLOAD, COLOR_UPLOAD]
        )
        if self.gencsv:
            genCSV("outputs/{}_total_transfer_by_hour.csv".format(self.output_filename), data)
        if self.genpng:
            tcbh.write_image("outputs/{}_total_transfer_by_hour.png".format(self.output_filename))
        if self.gensvg:
            tcbh.write_image("outputs/{}_total_transfer_by_hour.svg".format(self.output_filename))
        tcbh_for_pdf = tcbh.to_image(format = "png", width = FRAME_WIDTH * 3, height = FRAME_HEIGHT * 3, scale = 1)
        return Image(io.BytesIO(tcbh_for_pdf), FRAME_WIDTH, FRAME_HEIGHT)

    def _group_transfer_by_hour(self, group_name):
        # Transfer by Hour
        sorted_by_group_by_hour = dict(sorted(self.tc.by_group_by_hour[group_name].items()))
        self.logger.debug("sorted_by_group_by_hour: %s", sorted_by_group_by_hour)
        hour_axis = list(sorted_by_group_by_hour.keys())
        data = {
            "axis": hour_axis,
            "down": [sorted_by_group_by_hour[i]["down"] for i in hour_axis],
            "up": [sorted_by_group_by_hour[i]["up"] for i in hour_axis]
        }
        tcbgbh = gen_graph_transfer_by_tick(
            data = data,
            dtick = self._calc_dtick(group_name),
            title = "Transfer by Hour for Group: {}".format(group_name),
            linewidth = 2.0,
            colors = [COLOR_DOWNLOAD, COLOR_UPLOAD]
        )
        if self.gencsv:
            genCSV("outputs/{}_transfer_by_hour_for_group_{}.csv".format(self.output_filename, group_name), data)
        if self.genpng:
            tcbgbh.write_image("outputs/{}_transfer_by_hour_for_group_{}.png".format(self.output_filename, group_name))
        if self.gensvg:
            tcbgbh.write_image("outputs/{}_transfer_by_hour_for_group_{}.svg".format(self.output_filename, group_name))
        tcbgbh_for_pdf = tcbgbh.to_image(format = "png", width = FRAME_WIDTH * 3, height = FRAME_HEIGHT * 3, scale = 1)
        return Image(io.BytesIO(tcbgbh_for_pdf), FRAME_WIDTH, FRAME_HEIGHT)

    def _summary_requests_per_minute(self):
        # Requests per minute graph
        requests_by_minute = dict(sorted(self.rc.get_requests_per_minute().items()))
        hour_peaks = dict(sorted(self.rc.get_hour_peaks().items()))
        day_peaks = dict(sorted(self.rc.get_day_peaks().items()))
        self.logger.debug("requests_by_minute: %s", requests_by_minute)
        self.logger.debug("requests_by_minute hour_peaks: %s", hour_peaks)
        self.logger.debug("requests_by_minute day_peaks: %s", day_peaks)
        minute_axis = list(requests_by_minute.keys())
        hour_axis = list(hour_peaks.keys())
        day_axis = list(day_peaks.keys())
        data = {
            "rpm": {
                "axis": minute_axis,
                "Upload": [requests_by_minute[i]["upload"] for i in minute_axis],
                "Download": [requests_by_minute[i]["download"] for i in minute_axis]
            },
            # "hour_peaks": {
            #     "axis": hour_axis,
            #     "Peak RPM per Hour": [hour_peaks[i] for i in hour_axis]
            # },
            # "day_peaks": {
            #     "axis": day_axis,
            #     "Peak RPM per Day": [day_peaks[i] for i in day_axis]
            # }
        }
        rcrpm = gen_graph_requests_by_tick_with_peaks(
            data = data,
            dtick = self._calc_dtick(),
            title = "Total Requests per Minute",
            stacking = True,
            colors = [COLOR_UPLOAD, COLOR_DOWNLOAD]
        )
        if self.gencsv:
            genCSV("outputs/{}_total_requests_per_minute.csv".format(self.output_filename), data["rpm"])
        if self.genpng:
            rcrpm.write_image("outputs/{}_total_requests_per_minute.png".format(self.output_filename))
        if self.gensvg:
            rcrpm.write_image("outputs/{}_total_requests_per_minute.svg".format(self.output_filename))
        rcrpm_for_pdf = rcrpm.to_image(format = "png", width = FRAME_WIDTH * 3, height = FRAME_HEIGHT * 3, scale = 1)
        return Image(io.BytesIO(rcrpm_for_pdf), FRAME_WIDTH, FRAME_HEIGHT)

    def _group_requests_per_minute(self, group_name):
        # Requests per minute graph
        requests_by_group_by_minute = dict(sorted(self.rc.get_requests_per_minute(group_name).items()))
        self.logger.debug("requests_by_group_by_minute: %s", requests_by_group_by_minute)
        minute_axis = list(requests_by_group_by_minute.keys())
        data = {
            "axis": minute_axis,
            "Upload": [requests_by_group_by_minute[i]["upload"] for i in minute_axis],
            "Download": [requests_by_group_by_minute[i]["download"] for i in minute_axis]
        }
        rcrpmbg = gen_graph_requests_by_tick(
            data = data,
            dtick = self._calc_dtick(group_name),
            title = "Requests per Minute for Group: {}".format(group_name),
            stacking = True,
            colors = [COLOR_UPLOAD, COLOR_DOWNLOAD]
        )
        if self.gencsv:
            genCSV("outputs/{}_requests_per_minute_for_group_{}.csv".format(self.output_filename, group_name), data)
        if self.genpng:
            rcrpmbg.write_image("outputs/{}_requests_per_minute_for_group_{}.png".format(self.output_filename, group_name))
        if self.gensvg:
            rcrpmbg.write_image("outputs/{}_requests_per_minute_for_group_{}.svg".format(self.output_filename, group_name))
        rcrpmbg_for_pdf = rcrpmbg.to_image(format = "png", width = FRAME_WIDTH * 3, height = FRAME_HEIGHT * 3, scale = 1)
        return Image(io.BytesIO(rcrpmbg_for_pdf), FRAME_WIDTH, FRAME_HEIGHT)

    def _summary_slow_requests_per_minute(self):
        # Slow Requests per Minute
        slow_requests_by_minute = dict(sorted(self.sc.get_slow_by_minute().items()))
        self.logger.debug("slow_requests_by_minute: %s", slow_requests_by_minute)
        minute_axis = list(slow_requests_by_minute.keys())
        data = {
            "axis": minute_axis,
            "0.1 - 1 sec": None if self.only_bad_stuff else [slow_requests_by_minute[i]["0.1 - 1 sec"] for i in minute_axis],
            "1 - 9 sec": None if self.only_bad_stuff else [slow_requests_by_minute[i]["1 - 9 sec"] for i in minute_axis],
            "10 - 99 sec": [slow_requests_by_minute[i]["10 - 99 sec"] for i in minute_axis],
            "100 - 999 sec": [slow_requests_by_minute[i]["100 - 999 sec"] for i in minute_axis],
            "1000+ sec": [slow_requests_by_minute[i]["1000+ sec"] for i in minute_axis]
        }
        scsrpm = gen_graph_requests_by_tick(
            data = data,
            dtick = self._calc_dtick(),
            title = "Total Slow Requests per Minute",
            stacking = True
        )
        if self.gencsv:
            genCSV("outputs/{}_total_slow_requests_per_minute.csv".format(self.output_filename), data)
        if self.genpng:
            scsrpm.write_image("outputs/{}_total_slow_requests_per_minute.png".format(self.output_filename))
        if self.gensvg:
            scsrpm.write_image("outputs/{}_total_slow_requests_per_minute.svg".format(self.output_filename))
        scsrpm_for_pdf = scsrpm.to_image(format = "png", width = FRAME_WIDTH * 3, height = FRAME_HEIGHT * 3, scale = 1)
        return Image(io.BytesIO(scsrpm_for_pdf), FRAME_WIDTH, FRAME_HEIGHT)

    def _group_slow_requests_per_minute(self, group_name):
        # Slow Requests per Minute
        slow_requests_by_group_by_minute = dict(sorted(self.sc.get_slow_by_minute(group_name).items()))
        self.logger.debug("slow_requests_by_group_by_minute: %s", slow_requests_by_group_by_minute)
        minute_axis = list(slow_requests_by_group_by_minute.keys())
        self.logger.debug("minute_axis: %s", minute_axis)
        scsrbgpm = gen_graph_requests_by_tick(
            data = {
                "axis": minute_axis,
                "0.1 - 1 sec": None if self.only_bad_stuff else [slow_requests_by_group_by_minute[i]["0.1 - 1 sec"] for i in minute_axis],
                "1 - 9 sec": None if self.only_bad_stuff else [slow_requests_by_group_by_minute[i]["1 - 9 sec"] for i in minute_axis],
                "10 - 99 sec": [slow_requests_by_group_by_minute[i]["10 - 99 sec"] for i in minute_axis],
                "100 - 999 sec": [slow_requests_by_group_by_minute[i]["100 - 999 sec"] for i in minute_axis],
                "1000+ sec": [slow_requests_by_group_by_minute[i]["1000+ sec"] for i in minute_axis]
            },
            dtick = self._calc_dtick(group_name),
            title = "Slow Requests per Minute for Group: {}".format(group_name),
            stacking = True
        )
        if self.genpng:
            scsrbgpm.write_image("outputs/{}_slow_requests_per_minute_for_group_{}.png".format(self.output_filename, group_name))
        if self.gensvg:
            scsrbgpm.write_image("outputs/{}_slow_requests_per_minute_for_group_{}.svg".format(self.output_filename, group_name))
        scsrbgpm_for_pdf = scsrbgpm.to_image(format = "png", width = FRAME_WIDTH * 3, height = FRAME_HEIGHT * 3, scale = 1)
        return Image(io.BytesIO(scsrbgpm_for_pdf), FRAME_WIDTH, FRAME_HEIGHT)

    def _summary_total_vs_slow_requests_per_minute(self):
        total_requests_by_minute = dict(sorted(self.rc.get_requests_per_minute().items()))
        slow_requests_by_minute = dict(sorted(self.sc.get_slow_by_minute().items()))
        total_minute_axis = list(total_requests_by_minute.keys())
        slow_minute_axis = list(slow_requests_by_minute.keys())
        data = {
            "axis": total_minute_axis,
            "Total (Left)": [total_requests_by_minute[i]["total"] for i in total_minute_axis]
        }
        data2 = {
            "axis": slow_minute_axis,
            "Slow (Right)": [(slow_requests_by_minute[i]["10 - 99 sec"] + slow_requests_by_minute[i]["100 - 999 sec"] + slow_requests_by_minute[i]["1000+ sec"]) for i in slow_minute_axis]
        }
        scsvsrpm = gen_graph_requests_by_tick_dual(
            data = data,
            data2 = data2,
            dtick = self._calc_dtick(),
            title = "Total vs Slow Requests per Minute",
            linewidth = 2.0,
            colors = [COLOR_PASTEL_BLUE, COLOR_PASTEL_RED]
        )
        if self.gencsv:
            genCSV("outputs/{}_total_vs_slow_requests_per_minute.csv".format(self.output_filename), data)
        if self.genpng:
            scsvsrpm.write_image("outputs/{}_total_vs_slow_requests_per_minute.png".format(self.output_filename))
        if self.gensvg:
            scsvsrpm.write_image("outputs/{}_total_vs_slow_requests_per_minute.svg".format(self.output_filename))
        scsvsrpm_for_pdf = scsvsrpm.to_image(format = "png", width = FRAME_WIDTH * 3, height = FRAME_HEIGHT * 3, scale = 1)
        return Image(io.BytesIO(scsvsrpm_for_pdf), FRAME_WIDTH, FRAME_HEIGHT)

    def _summary_average_total_vs_slow_requests_per_minute(self):
        total_requests_by_minute = dict(sorted(self.rc.get_requests_per_minute().items()))
        slow_requests_by_minute = dict(sorted(self.sc.get_slow_by_minute().items()))
        total_minute_axis = list(total_requests_by_minute.keys())
        slow_minute_axis = list(slow_requests_by_minute.keys())
        # Moving Average
        window_size = 5 # Five Minute Moving Average
        total_rpm_avg = [None, None]  # FIXME: Hardcoding for now.  Probably could use int(window_size / 2).
        for i in range(len(total_minute_axis) - window_size + 1):
            window = [total_requests_by_minute[j]["total"] for j in total_minute_axis[i:i+window_size]]
            window_avg = int(sum(window) / window_size)
            self.logger.debug("Moving Average Total Step - window: %s, window_avg: %d", window, window_avg)
            total_rpm_avg.append(window_avg)
        total_rpm_avg.append(None)  # FIXME: Hardcoding for now.  Probably could use int(window_size / 2).
        total_rpm_avg.append(None)  # FIXME: Hardcoding for now.  Probably could use int(window_size / 2).
        slow_rpm_avg = [None, None]  # FIXME: Hardcoding for now.  Probably could use int(window_size / 2).
        for i in range(len(slow_minute_axis) - window_size + 1):
            window = [(slow_requests_by_minute[j]["10 - 99 sec"] + slow_requests_by_minute[j]["100 - 999 sec"] + slow_requests_by_minute[j]["1000+ sec"]) for j in slow_minute_axis[i:i+window_size]]
            window_avg = int(sum(window) / window_size)
            self.logger.debug("Moving Average Slow Step - window: %s, window_avg: %d", window, window_avg)
            slow_rpm_avg.append(window_avg)
        slow_rpm_avg.append(None)  # FIXME: Hardcoding for now.  Probably could use int(window_size / 2).
        slow_rpm_avg.append(None)  # FIXME: Hardcoding for now.  Probably could use int(window_size / 2).
        data = {
            "axis": total_minute_axis,
            "Average Total (Left)": total_rpm_avg
        }
        data2 = {
            "axis": slow_minute_axis,
            "Average Slow (Right)": slow_rpm_avg
        }
        scsvsrpma = gen_graph_requests_by_tick_dual(
            data = data,
            data2 = data2,
            dtick = self._calc_dtick(),
            title = "Average Total vs Average Slow Requests per Minute (Five Minute Moving Mean Average)",
            linewidth = 2.0,
            colors = [COLOR_PASTEL_BLUE, COLOR_PASTEL_RED]
        )
        # FIXME: CSV Generator should probably allow dual data...
        if self.gencsv:
            genCSV("outputs/{}_average_total_vs_slow_requests_per_minute.csv".format(self.output_filename), data)
        if self.genpng:
            scsvsrpma.write_image("outputs/{}_average_total_vs_slow_requests_per_minute.png".format(self.output_filename))
        if self.gensvg:
            scsvsrpma.write_image("outputs/{}_average_total_vs_slow_requests_per_minute.svg".format(self.output_filename))
        scsvsrpma_for_pdf = scsvsrpma.to_image(format = "png", width = FRAME_WIDTH * 3, height = FRAME_HEIGHT * 3, scale = 1)
        return Image(io.BytesIO(scsvsrpma_for_pdf), FRAME_WIDTH, FRAME_HEIGHT)

    def _group_traffic_types_per_minute(self, group_name = None):
        # Traffic Types per Minute
        traffic_types_by_minute = None
        title_str = ""
        if group_name is None:
            traffic_types_by_minute = dict(sorted(self.ttc.get_counts_by_minute().items()))
            title_str = "Total Traffic Types per Minute"
        else:
            traffic_types_by_minute = dict(sorted(self.ttc.get_counts_by_minute(group_name).items()))
            title_str = "Traffic Types per Minute for Group: {}".format(group_name)
        self.logger.debug("traffic_types_by_minute( group_name = %s ): %s", group_name, traffic_types_by_minute)
        minute_axis = list(traffic_types_by_minute.keys())
        # FIXME: Create this graph based on the traffic types, not by hand
        # FIXME: Add the items in a for loop
        data = {
            "axis": minute_axis,
            "docker": [traffic_types_by_minute[i]["docker"] for i in minute_axis],
            "helm": [traffic_types_by_minute[i]["helm"] for i in minute_axis],
            "npm": [traffic_types_by_minute[i]["npm"] for i in minute_axis],
            "nuget": [traffic_types_by_minute[i]["nuget"] for i in minute_axis],
            "pypi": [traffic_types_by_minute[i]["pypi"] for i in minute_axis]
        }
        ttcttbgpm = gen_graph_requests_by_tick(
            data = data,
            dtick = self._calc_dtick(group_name),
            title = title_str,
            stacking = True
        )
        if self.gencsv:
            genCSV("outputs/{}_traffic_types_per_minute_for_group_{}.csv".format(self.output_filename, group_name), data)
        if self.genpng:
            ttcttbgpm.write_image("outputs/{}_traffic_types_per_minute_for_group_{}.png".format(self.output_filename, group_name))
        if self.gensvg:
            ttcttbgpm.write_image("outputs/{}_traffic_types_per_minute_for_group_{}.svg".format(self.output_filename, group_name))
        ttcttbgpm_for_pdf = ttcttbgpm.to_image(format = "png", width = FRAME_WIDTH * 3, height = FRAME_HEIGHT * 3, scale = 1)
        return Image(io.BytesIO(ttcttbgpm_for_pdf), FRAME_WIDTH, FRAME_HEIGHT)

    def _group_traffic_types_per_minute_per_type(self, group_name = None, traffic_type = None):
        # Traffic Types per Minute for a single type of traffic
        traffic_types_by_minute = None
        title_str = ""
        filename_str = ""
        if traffic_type not in self.ttc.TRAFFIC_TYPES:
            # FIXME: Raise error?  This is programmatic, so probably shouldn't be allowed...
            raise ValueError("BAD TRAFFIC TYPE!")
        if group_name is None:
            # FIXME: Should this just get the data for one requested type?  Or still return the whole set?
            traffic_types_by_minute = dict(sorted(self.ttc.get_counts_by_minute().items()))
            title_str = "Total Traffic for Type {} per Minute".format(traffic_type)
            filename_str = "total_traffic_for_type_{}_per_minute".format(traffic_type)
        else:
            # FIXME: Should this just get the data for one requested type?  Or still return the whole set?
            traffic_types_by_minute = dict(sorted(self.ttc.get_counts_by_minute(group_name).items()))
            title_str = "Traffic for Type {} per Minute for Group: {}".format(traffic_type, group_name)
            filename_str = "traffic_for_type_{}_per_minute_for_group".format(traffic_type, group_name)
        self.logger.debug("_group_traffic_types_per_minute_per_type( group_name = %s ): %s", group_name, traffic_types_by_minute)
        minute_axis = list(traffic_types_by_minute.keys())
        # FIXME: Should a line for the total requests per minute be added as reference?
        ttcttbgpm = gen_graph_requests_by_tick(
            data = {
                "axis": minute_axis,
                traffic_type: [traffic_types_by_minute[i][traffic_type] for i in minute_axis]
            },
            dtick = self._calc_dtick(group_name),
            title = title_str,
            stacking = True
        )
        if self.genpng:
            ttcttbgpm.write_image("outputs/{}_{}.png".format(self.output_filename, filename_str))
        if self.gensvg:
            ttcttbgpm.write_image("outputs/{}_{}.svg".format(self.output_filename, filename_str))
        ttcttbgpm_for_pdf = ttcttbgpm.to_image(format = "png", width = FRAME_WIDTH * 3, height = FRAME_HEIGHT * 3, scale = 1)
        return Image(io.BytesIO(ttcttbgpm_for_pdf), FRAME_WIDTH, FRAME_HEIGHT)

    def _group_status_codes_per_minute(self, group_name):
        # Status Codes per Minute
        status_codes_by_group_by_minute = dict(sorted(self.scc.get_counts_by_minute(group_name).items()))
        self.logger.debug("status_codes_by_group_by_minute: %s", status_codes_by_group_by_minute)
        minute_axis = list(status_codes_by_group_by_minute.keys())
        data = {
            "axis": minute_axis,
            "200": None if self.only_bad_stuff else [status_codes_by_group_by_minute[i]["200"] for i in minute_axis],
            "201": None if self.only_bad_stuff else [status_codes_by_group_by_minute[i]["201"] for i in minute_axis],
            "401": [status_codes_by_group_by_minute[i]["401"] for i in minute_axis],
            "403": [status_codes_by_group_by_minute[i]["403"] for i in minute_axis],
            "404": [status_codes_by_group_by_minute[i]["404"] for i in minute_axis],
            "503": [status_codes_by_group_by_minute[i]["503"] for i in minute_axis]
        }
        sccttbgpm = gen_graph_requests_by_tick(
            data = data,
            dtick = self._calc_dtick(group_name),
            title = "Status Codes per Minute for Group: {}".format(group_name),
            stacking = True
        )
        if self.gencsv:
            genCSV("outputs/{}_status_codes_per_minute_for_group_{}.csv".format(self.output_filename, group_name), data)
        if self.genpng:
            sccttbgpm.write_image("outputs/{}_status_codes_per_minute_for_group_{}.png".format(self.output_filename, group_name))
        if self.gensvg:
            sccttbgpm.write_image("outputs/{}_status_codes_per_minute_for_group_{}.svg".format(self.output_filename, group_name))
        sccttbgpm_for_pdf = sccttbgpm.to_image(format = "png", width = FRAME_WIDTH * 3, height = FRAME_HEIGHT * 3, scale = 1)
        return Image(io.BytesIO(sccttbgpm_for_pdf), FRAME_WIDTH, FRAME_HEIGHT)

    def _add_summary(self):
        self.logger.info("_add_summary()")
        self.doc.group_name = None

        self.story.append(self._summary_table())
        self.story.append(self._summary_transfer_by_day())
        self.story.append(self._summary_transfer_by_hour())
        self.story.append(self._summary_requests_per_minute())
        self.story.append(self._summary_slow_requests_per_minute())
        self.story.append(self._summary_total_vs_slow_requests_per_minute())
        self.story.append(self._summary_average_total_vs_slow_requests_per_minute())
        self.story.append(self._group_traffic_types_per_minute())

    def _add_group(self, group_name):
        self.logger.info("_add_group(group_name = %s)", group_name)
        self.doc.group_name = group_name

        self.story.append(self._group_table(group_name))
        self.story.append(self._group_transfer_by_hour(group_name))
        self.story.append(self._group_requests_per_minute(group_name))
        self.story.append(self._group_slow_requests_per_minute(group_name))

        # FIXME: Split the status codes graph similar to traffic.
        self.story.append(self._group_status_codes_per_minute(group_name))

        # FIXME: Should this combined graph still be presented?
        self.story.append(self._group_traffic_types_per_minute(group_name))

        # FIXME: Make the following come from the list of traffic types from the TrafficTypesCalc class
        # FIXME: Should the graphs that have no traffic still be presented?
        self.story.append(self._group_traffic_types_per_minute_per_type(group_name, "docker"))
        self.story.append(self._group_traffic_types_per_minute_per_type(group_name, "helm"))
        self.story.append(self._group_traffic_types_per_minute_per_type(group_name, "npm"))
        self.story.append(self._group_traffic_types_per_minute_per_type(group_name, "nuget"))
        self.story.append(self._group_traffic_types_per_minute_per_type(group_name, "pypi"))
