#!/usr/bin/env python3

### IMPORTS ###
from reportlab.platypus import Frame, PageTemplate
from reportlab.lib.units import inch

from .styles import PAGE_TYPE, PAGE_MARGIN_LEFT, FRAME_WIDTH, FRAME_HEIGHT

### GLOBALS ###

### FUNCTIONS ###
# This method is used to draw static items on the page before other drawing is done (e.g. behind other elements).
def on_page_summary(canvas, document):
    canvas.saveState()
    canvas.setFont('Helvetica-Bold', 24)
    canvas.drawString(0.75 * inch, 10.25 * inch, "Total for All Groups")
    canvas.restoreState()

# This method is used to draw static items on the page after other drawing is done (e.g. on top of other elements).
def on_page_end_summary(canvas, document):
    canvas.saveState()
    canvas.setFont('Helvetica', 10)
    canvas.drawString(7.25 * inch, 0.5 * inch, "Page {}".format(document.page)) # FIXME: Total pages number?
    canvas.restoreState()

def gen_summary_page_template():
    # Create frames
    upper_frame = Frame(
        x1 = PAGE_MARGIN_LEFT,
        y1 = 700 - (1 * FRAME_HEIGHT) + 10, # FIXME: In points, not inches
        width = FRAME_WIDTH,
        height = FRAME_HEIGHT,
        leftPadding = 0,
        bottomPadding = 0,
        rightPadding = 0,
        topPadding = 0,
        id = "upper_frame",
        showBoundary = 0
    )
    lower_frame = Frame(
        x1 = PAGE_MARGIN_LEFT,
        y1 = 700 - (2 * FRAME_HEIGHT) - 10, # FIXME: In points, not inches
        width = FRAME_WIDTH,
        height = FRAME_HEIGHT,
        leftPadding = 0,
        bottomPadding = 0,
        rightPadding = 0,
        topPadding = 0,
        id = "lower_frame",
        showBoundary = 0
    )

    # Create the page template and return it
    return PageTemplate(
        id = "summary_page",
        frames = [upper_frame, lower_frame],
        onPage = on_page_summary,
        onPageEnd = on_page_end_summary,
        pagesize = PAGE_TYPE
    )

### CLASSES ###
