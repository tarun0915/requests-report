#!/usr/bin/env python3

### IMPORTS ###
import logging

# FIXME: Should try giving the graphing in reportlib a try.
import plotly.graph_objects

from .styles import *

### GLOBALS ###

### FUNCTIONS ###
def gen_graph_transfer_by_tick(data, dtick, title, linewidth = 0.5, stacking = False, colors = []):
    data_keys = list(data.keys())
    data_keys.remove("axis")
    fig_requests_by_tick = plotly.graph_objects.Figure()
    tmp_color_index = 0
    gcolors = colors if len(colors) > 0 else GRAPH_COLORS
    for item in data_keys:
        if data[item] is not None:
            fig_requests_by_tick.add_trace(plotly.graph_objects.Scatter(
                x = data["axis"],
                y = data[item],
                name = str(item),
                line = {"color": gcolors[tmp_color_index], "width": linewidth},
                mode = "lines" if linewidth < 2.0 else "lines+markers",
                stackgroup = "one" if stacking is True else None
            ))
            tmp_color_index = (tmp_color_index + 1) % len(gcolors)
    fig_requests_by_tick.update_layout(
        title = title,
        yaxis_title = "Bytes",
        xaxis = {"dtick": dtick, "tickangle": -90, "tickformat": "%Y-%m-%d %H:%M", "minor_dtick": 3600000.0},
        yaxis = {"exponentformat": "SI"},
        legend = {"orientation": "h", "yanchor": "bottom", "y": 1.02, "xanchor": "right", "x": 1},
        font = {"size": 18}
    )
    return fig_requests_by_tick

def gen_graph_requests_by_tick(data, dtick, title, linewidth = 0.5, stacking = False, colors = []):
    data_keys = list(data.keys())
    data_keys.remove("axis")
    fig_requests_by_tick = plotly.graph_objects.Figure()
    tmp_color_index = 0
    gcolors = colors if len(colors) > 0 else GRAPH_COLORS
    for item in data_keys:
        if data[item] is not None:
            fig_requests_by_tick.add_trace(plotly.graph_objects.Scatter(
                x = data["axis"],
                y = data[item],
                name = str(item),
                line = {"color": gcolors[tmp_color_index], "width": linewidth},
                mode = "lines" if linewidth < 2.0 else "lines+markers",
                stackgroup = "one" if stacking is True else None
            ))
            tmp_color_index = (tmp_color_index + 1) % len(gcolors)
    fig_requests_by_tick.update_layout(
        title = title,
        yaxis_title = "Number of Requests",
        xaxis = {"dtick": dtick, "tickangle": -90, "tickformat": "%Y-%m-%d %H:%M", "minor_dtick": 3600000.0},
        yaxis = {"exponentformat": "B"},
        legend = {"orientation": "h", "yanchor": "bottom", "y": 1.02, "xanchor": "right", "x": 1},
        font = {"size": 18}
    )
    return fig_requests_by_tick

def gen_graph_requests_by_tick_dual(data, data2, dtick, title, linewidth = 0.5, stacking = False, colors = []):
    data_keys = list(data.keys())
    data_keys.remove("axis")
    data2_keys = list(data2.keys())
    data2_keys.remove("axis")
    fig_requests_by_tick = plotly.graph_objects.Figure()
    tmp_color_index = 0
    gcolors = colors if len(colors) > 0 else GRAPH_COLORS
    for item in data_keys:
        if data[item] is not None:
            fig_requests_by_tick.add_trace(plotly.graph_objects.Scatter(
                x = data["axis"],
                y = data[item],
                name = str(item),
                line = {"color": gcolors[tmp_color_index], "width": linewidth},
                mode = "lines",
                stackgroup = "one" if stacking is True else None
            ))
            tmp_color_index = (tmp_color_index + 1) % len(gcolors)
    for item in data2_keys:
        if data2[item] is not None:
            fig_requests_by_tick.add_trace(plotly.graph_objects.Scatter(
                x = data2["axis"],
                y = data2[item],
                yaxis = "y2",
                name = str(item),
                line = {"color": gcolors[tmp_color_index], "width": linewidth},
                mode = "lines",
                stackgroup = "one" if stacking is True else None
            ))
            tmp_color_index = (tmp_color_index + 1) % len(gcolors)
    fig_requests_by_tick.update_layout(
        title = title,
        xaxis = {"dtick": dtick, "tickangle": -90, "tickformat": "%Y-%m-%d %H:%M", "minor_dtick": 3600000.0},
        yaxis = {"title": "Number of Requests", "exponentformat": "B"},
        yaxis2 = {"title": "Number of Requests", "exponentformat": "B", "overlaying": "y", "side": "right"},
        legend = {"orientation": "h", "yanchor": "bottom", "y": 1.02, "xanchor": "right", "x": 1},
        font = {"size": 18}
    )
    return fig_requests_by_tick

def gen_graph_requests_by_tick_with_peaks(data, dtick, title, linewidth = 0.5, stacking = False, colors = []):
    rpm_data = data["rpm"]
    hour_data = data["hour_peaks"] if "hour_peaks" in data else None
    day_data = data["day_peaks"] if "day_peaks" in data else None
    rpm_data_keys = list(rpm_data.keys())
    rpm_data_keys.remove("axis")
    fig_requests_by_tick = plotly.graph_objects.Figure()
    tmp_color_index = 0
    gcolors = colors if len(colors) > 0 else GRAPH_COLORS
    for item in rpm_data_keys:
        if rpm_data[item] is not None:
            fig_requests_by_tick.add_trace(plotly.graph_objects.Scatter(
                x = rpm_data["axis"],
                y = rpm_data[item],
                name = str(item),
                line = {"color": gcolors[tmp_color_index], "width": linewidth},
                mode = "lines" if linewidth < 2.0 else "lines+markers",
                stackgroup = "one" if stacking is True else None
            ))
            tmp_color_index = (tmp_color_index + 1) % len(gcolors)
    if hour_data is not None:
        peak_data_keys = list(hour_data.keys())
        peak_data_keys.remove("axis")
        for item in peak_data_keys:
            if hour_data[item] is not None:
                fig_requests_by_tick.add_trace(plotly.graph_objects.Scatter(
                    x = hour_data["axis"],
                    y = hour_data[item],
                    name = str(item),
                    line = {"color": gcolors[tmp_color_index], "width": linewidth},
                    mode = "lines+markers"
                ))
                tmp_color_index = (tmp_color_index + 1) % len(gcolors)
    if day_data is not None:
        peak_data_keys = list(day_data.keys())
        peak_data_keys.remove("axis")
        for item in peak_data_keys:
            if day_data[item] is not None:
                fig_requests_by_tick.add_trace(plotly.graph_objects.Scatter(
                    x = day_data["axis"],
                    y = day_data[item],
                    name = str(item),
                    line = {"color": gcolors[tmp_color_index], "width": linewidth},
                    mode = "lines+markers"
                ))
                tmp_color_index = (tmp_color_index + 1) % len(gcolors)
    fig_requests_by_tick.update_layout(
        title = title,
        yaxis_title = "Number of Requests",
        xaxis = {"dtick": dtick, "tickangle": -90, "tickformat": "%Y-%m-%d %H:%M", "minor_dtick": 3600000.0},
        yaxis = {"exponentformat": "B"},
        legend = {"orientation": "h", "yanchor": "bottom", "y": 1.02, "xanchor": "right", "x": 1},
        font = {"size": 18}
    )
    return fig_requests_by_tick

### CLASSES ###
