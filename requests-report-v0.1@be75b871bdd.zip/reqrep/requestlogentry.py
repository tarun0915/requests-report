#!/usr/bin/env python3

### IMPORTS ###
import datetime
import logging

### GLOBALS ###

### FUNCTIONS ###

### CLASSES ###
class RequestLogEntry:
    def __init__(self, group, log_name):
        self.logger = logging.getLogger(type(self).__name__)
        self.group = group
        self.log_name = log_name
        # Default values
        self.timestamp = datetime.datetime.now()
        self.method = "GET"
        self.path = "/"
        self.status_code = "400"
        self.up_size = 0 # bytes
        self.down_size = 0 # bytes
        self.duration = 0 # ms

class RequestLogEntrySeven(RequestLogEntry):
    def __init__(self, group, log_name, input_line):
        super().__init__(group, log_name)
        self.logger = logging.getLogger(type(self).__name__)
        # This is a single line of a request log for Artifactory Version 7.*
        # Example Lines:
        # - 2023-04-07T04:09:49.449Z|827ad60fcf158238|10.1.202.14|anonymous|GET|/centos/7.9.2009/os/x86_64/repodata/repomd.xml:properties|302|-1|0|0|Artifactory/7.46.10 74610900
        # - 2023-04-07T04:09:49.465Z|a1347a2e5ad0d45b|10.233.37.173|anonymous|GET|/api/pypi/dataengineering-pypi/packages/packages/ec/ab/a440db757401a1e8863c9abb374a77cb2884eda74ffbf555dedcf1fbe7f6/frozenlist-1.3.3-cp38-cp38-manylinux_2_5_x86_64.manylinux1_x86_64.manylinux_2_17_x86_64.manylinux2014_x86_64.whl|200|-1|161300|6|pip/21.0.1 {"ci":null,"cpu":"x86_64","distro":{"id":"focal","libc":{"lib":"glibc","version":"2.31"},"name":"Ubuntu","version":"20.04"},"implementation":{"name":"CPython","version":"3.8.10"},"installer":{"name":"pip","version":"21.0.1"},"openssl_version":"OpenSSL 1.1.1f  31 Mar 2020","python":"3.8.10","setuptools_version":"52.0.0","system":{"name":"Linux","release":"5.4.0-1096-aws"}}
        # - 2023-04-07T04:09:49.478Z|76af5d05747afb2c|10.1.202.14|anonymous|HEAD|/epel/7/x86_64/repodata/repomd.xml|200|-1|4851|2|Artifactory/7.46.10 74610900
        # - 2023-04-05T12:23:37.826Z|3e96f7737265e393|127.0.0.1|anonymous|GET|/api/v1/system/readiness|200|-1|0|1|JFrog-Router/7.42.0-1
        # - 2023-04-05T12:23:37.828Z|fe827b51f5d3ffb9|10.195.80.195|tokenservices-build|POST|/api/docker/tokenservices-docker/v2/key-manager/blobs/uploads/|202|0|0|0|buildkit/v0.11
        # - 2023-04-05T12:23:37.831Z|9bab4816c0b27021|10.195.80.195|tokenservices-build|HEAD|/api/docker/tokenservices-docker/v2/key-manager/blobs/sha256:f91dc3ff8ed55a0cfecf56a6287d4b9f7c0726e4b8269d7c312083d9da6aab87|404|-1|157|24|buildkit/v0.11
        chunks = input_line.split('|')
        self.timestamp = datetime.datetime.fromisoformat(chunks[0])
        self.method = chunks[4]
        self.path = chunks[5]
        self.status_code = chunks[6]
        self.up_size = int(chunks[7]) # bytes
        self.down_size = int(chunks[8]) # bytes
        self.duration = int(chunks[9]) # ms

class RequestLogEntrySix(RequestLogEntry):
    def __init__(self, group, log_name, input_line):
        super().__init__(group, log_name)
        self.logger = logging.getLogger(type(self).__name__)
        # This is a single line of a request log for Artifactory Version 6.*
        # Example Lines:
        #   0              1  2       3            4                    5   6                         7        8   9
        # - 20230825060002|50|REQUEST|10.149.6.151|artifactory_deployer|PUT|/maven-local/com/file.jar|HTTP/1.1|201|1321
        # - 20230825060007|341|REQUEST|10.149.6.153|jenkins_reader|GET|/maven-all/com/file.pom|HTTP/1.1|404|0
        # - 20230825060007|1|REQUEST|10.149.6.153|non_authenticated_user|GET|/maven-all/com/file.pom|HTTP/1.1|401|0
        # NOTE: Timestamp is not unix time.  It's "YYYYMMDDhhmmss".
        chunks = input_line.split('|')
        self.timestamp = datetime.datetime(
            year = int(chunks[0][0:4]),
            month = int(chunks[0][4:6]),
            day = int(chunks[0][6:8]),
            hour = int(chunks[0][8:10]),
            minute = int(chunks[0][10:12]),
            second = int(chunks[0][12:14]),
            tzinfo = datetime.timezone.utc
        )
        self.method = chunks[5]
        self.path = chunks[6]
        self.status_code = chunks[8]
        if self.method in ["PUT", "POST", "PATCH"]:
            self.up_size = int(chunks[9]) # bytes
        else:
            self.down_size = int(chunks[9]) # bytes
        self.duration = int(chunks[1]) # ms
