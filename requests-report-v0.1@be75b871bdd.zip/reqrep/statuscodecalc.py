#!/usr/bin/env python3

### IMPORTS ###
import datetime
import logging

### GLOBALS ###
STATUS_CODES = {
    "200": "200",
    "201": "201",
    "301": "301",
    "302": "302",
    "400": "400",
    "401": "401",
    "403": "403",
    "404": "404",
    "500": "500",
    "502": "502",
    "503": "503"
}

### FUNCTIONS ###
def get_empty_dict():
    empty_dict = {"0": 0}
    for i in STATUS_CODES:
        empty_dict[i] = 0
    return empty_dict

### CLASSES ###
class StatusCodeCalc:
    def __init__(self):
        self.logger = logging.getLogger(type(self).__name__)
        self.rle_count = 0
        self.counts = get_empty_dict()
        self.counts_by_minute = {}
        self.counts_by_group = {}
        self.counts_by_group_by_minute = {}

    def add_log_entry(self, rle):
        self.rle_count = self.rle_count + 1
        # Check which status code if found
        status_str = '0'
        for i in STATUS_CODES:
            if STATUS_CODES[i] in rle.status_code:
                status_str = i
                break

        # FIXME: DELETE ME!
        if status_str == "503":
            self.logger.debug("503! 503! 503!")

        # Calc the datetime minute timestamps that the request occurred
        minute_str = rle.timestamp.strftime('%Y-%m-%d %H:%M')

        self.counts[status_str] = self.counts[status_str] + 1

        if minute_str not in self.counts_by_minute:
            self.counts_by_minute[minute_str] = get_empty_dict()
        self.counts_by_minute[minute_str][status_str] = self.counts_by_minute[minute_str][status_str] + 1

        if rle.group not in self.counts_by_group:
            self.counts_by_group[rle.group] = get_empty_dict()
        self.counts_by_group[rle.group][status_str] = self.counts_by_group[rle.group][status_str] + 1

        if rle.group not in self.counts_by_group_by_minute:
            self.counts_by_group_by_minute[rle.group] = {}
        if minute_str not in self.counts_by_group_by_minute[rle.group]:
                self.counts_by_group_by_minute[rle.group][minute_str] = get_empty_dict()
        self.counts_by_group_by_minute[rle.group][minute_str][status_str] = self.counts_by_group_by_minute[rle.group][minute_str][status_str] + 1

    def get_counts(self, group = None):
        if group is not None:
            return self.counts_by_group[group]
        return self.counts

    def get_counts_by_minute(self, group = None):
        if group is not None:
            return self.counts_by_group_by_minute[group]
        return self.counts_by_minute
