#!/usr/bin/env python3

### IMPORTS ###
import os
import enum

### GLOBALS ###

### FUNCTIONS ###

### CLASSES ###
class BundleType(enum.Enum):
    UNKNOWN = 'unknown'
    LOG = 'log'
    LOGGZ = 'loggz'
    TARBALL = 'tarball'
    SUPPORT = 'support'

class Bundle:
    def __init__(self, group, name, root = "./inputs/", type = BundleType.UNKNOWN):
        self.group = group
        self.name = name
        self.root = root
        self.type = type

    def __str__(self):
        return "Bundle: group: {}, name: {}, type: {}".format(self.group, self.name, self.type)

    def get_path(self):
        if self.group == "default":
            return os.path.join(self.root, self.name)
        return os.path.join(self.root, self.group, self.name)
