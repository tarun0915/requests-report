#!/usr/bin/env python3

### IMPORTS ###
import datetime
import logging

### GLOBALS ###
EMPTY_SLOW_COUNTS_DICT = {
    "0.1 - 1 sec": 0,
    "1 - 9 sec": 0,
    "10 - 99 sec": 0,
    "100 - 999 sec": 0,
    "1000+ sec": 0
}

### FUNCTIONS ###

### CLASSES ###
class SlowCalc:
    def __init__(self):
        self.logger = logging.getLogger(type(self).__name__)
        self.rle_count = 0
        self.slow_counts = dict(EMPTY_SLOW_COUNTS_DICT)
        self.slow_counts_by_minute = {}
        self.slow_counts_by_group = {}
        self.slow_counts_by_group_by_minute = {}

    def add_log_entry(self, rle):
        self.rle_count = self.rle_count + 1
        # Calc the bin the count goes into
        category_str = ''
        if rle.duration < 100:
            return # Just going to shortcut sub 100ms requests for now, since they're "not slow"
        elif rle.duration < 1000:
            category_str = "0.1 - 1 sec"
        elif rle.duration < 10000:
            category_str = "1 - 9 sec"
        elif rle.duration < 100000:
            category_str = "10 - 99 sec"
        elif rle.duration < 1000000:
            category_str = "100 - 999 sec"
        elif rle.duration >= 1000000:
            category_str = "1000+ sec"
        # Calc the datetime minute timestamps that the request occurred
        minute_str = rle.timestamp.strftime('%Y-%m-%d %H:%M')

        self.slow_counts[category_str] = self.slow_counts[category_str] + 1

        if minute_str not in self.slow_counts_by_minute:
            self.slow_counts_by_minute[minute_str] = dict(EMPTY_SLOW_COUNTS_DICT)
        self.slow_counts_by_minute[minute_str][category_str] = self.slow_counts_by_minute[minute_str][category_str] + 1

        if rle.group not in self.slow_counts_by_group:
            self.slow_counts_by_group[rle.group] = dict(EMPTY_SLOW_COUNTS_DICT)
        self.slow_counts_by_group[rle.group][category_str] = self.slow_counts_by_group[rle.group][category_str] + 1

        if rle.group not in self.slow_counts_by_group_by_minute:
            self.slow_counts_by_group_by_minute[rle.group] = {}
        if minute_str not in self.slow_counts_by_group_by_minute[rle.group]:
                self.slow_counts_by_group_by_minute[rle.group][minute_str] = dict(EMPTY_SLOW_COUNTS_DICT)
        self.slow_counts_by_group_by_minute[rle.group][minute_str][category_str] = self.slow_counts_by_group_by_minute[rle.group][minute_str][category_str] + 1

    def get_slow_counts(self, group = None):
        if group is not None:
            # FIXME: Seems to be a bug is there's no data in a group
            if group not in self.slow_counts_by_group:
                return dict(EMPTY_SLOW_COUNTS_DICT)
            return self.slow_counts_by_group[group]
        return self.slow_counts

    def get_slow_by_minute(self, group = None):
        if group is not None:
            # FIXME: Seems to be a bug is there's no data in a group
            if group not in self.slow_counts_by_group_by_minute:
                return {}
            return self.slow_counts_by_group_by_minute[group]
        return self.slow_counts_by_minute
