#!/usr/bin/env python3

### IMPORTS ###
import datetime
import logging

### GLOBALS ###
TRAFFIC_PATHS = {
    "docker": "api/docker",
    "helm": "api/helm",
    "npm": "api/npm",
    "nuget": "api/nuget",
    "pypi": "api/pypi",
    "lfs": "api/lfs",
    "security": "api/security",
    "repository": "api/repository",
    "search": "api/search",
    "federation": "api/mirror/event/message"
}

### FUNCTIONS ###
def get_empty_dict():
    empty_dict = {"other": 0}
    for i in TRAFFIC_PATHS:
        empty_dict[i] = 0
    return empty_dict

### CLASSES ###
class TrafficTypesCalc:
    TRAFFIC_TYPES = list(TRAFFIC_PATHS.keys())

    def __init__(self):
        self.logger = logging.getLogger(type(self).__name__)
        self.rle_count = 0
        self.counts = get_empty_dict()
        self.counts_by_minute = {}
        self.counts_by_group = {}
        self.counts_by_group_by_minute = {}

    def add_log_entry(self, rle):
        self.rle_count = self.rle_count + 1
        # Check which traffic type if found
        category_str = 'other'
        for i in TRAFFIC_PATHS:
            if TRAFFIC_PATHS[i] in rle.path:
                category_str = i
                break
        # Calc the datetime minute timestamps that the request occurred
        minute_str = rle.timestamp.strftime('%Y-%m-%d %H:%M')

        self.counts[category_str] = self.counts[category_str] + 1

        if minute_str not in self.counts_by_minute:
            self.counts_by_minute[minute_str] = get_empty_dict()
        self.counts_by_minute[minute_str][category_str] = self.counts_by_minute[minute_str][category_str] + 1

        if rle.group not in self.counts_by_group:
            self.counts_by_group[rle.group] = get_empty_dict()
        self.counts_by_group[rle.group][category_str] = self.counts_by_group[rle.group][category_str] + 1

        if rle.group not in self.counts_by_group_by_minute:
            self.counts_by_group_by_minute[rle.group] = {}
        if minute_str not in self.counts_by_group_by_minute[rle.group]:
                self.counts_by_group_by_minute[rle.group][minute_str] = get_empty_dict()
        self.counts_by_group_by_minute[rle.group][minute_str][category_str] = self.counts_by_group_by_minute[rle.group][minute_str][category_str] + 1

    def get_counts(self, group = None):
        if group is not None:
            return self.counts_by_group[group]
        return self.counts

    def get_counts_by_minute(self, group = None):
        if group is not None:
            return self.counts_by_group_by_minute[group]
        return self.counts_by_minute
