#!/usr/bin/env python3

### IMPORTS ###
import datetime
import logging
import sqlite3

### GLOBALS ###

### FUNCTIONS ###

### CLASSES ###
class RequestsCalc:
    def __init__(self):
        self.logger = logging.getLogger(type(self).__name__)
        self.request_count = 0
        self.minute_counts = {}
        self.minute_counts_by_group = {}
        self.millisec_counts = {}
        self.conn = sqlite3.connect("requests.db")

        cur = self.conn.cursor()
        try:
            cur.execute("DROP TABLE requests")
        except sqlite3.OperationalError as ex:
            self.logger.debug("Expected: %s", ex)
        try:
            cur.execute("DROP TABLE millis")
        except sqlite3.OperationalError as ex:
            self.logger.debug("Expected: %s", ex)
        cur.execute("CREATE TABLE requests(timestamp, rlegroup, duration)")
        cur.execute("CREATE TABLE millis(timestamp, micros, rlegroup)")

    def add_log_entry(self, rle):
        self.request_count = self.request_count + 1
        # Calc the datetime minute timestamps that the request occurred
        minute_str = rle.timestamp.strftime('%Y-%m-%d %H:%M')
        micros_int = int(rle.timestamp.strftime('%f'))
        cur = self.conn.cursor()
        data = {"timestamp": minute_str, "rlegroup": rle.group, "duration": rle.duration}
        cur.execute("INSERT INTO requests VALUES(:timestamp, :rlegroup, :duration)", data)
        #self.conn.commit()

        # if minute_str not in self.minute_counts:
        #     self.minute_counts[minute_str] = 0
        # self.minute_counts[minute_str] = self.minute_counts[minute_str] + 1
        #
        # if not rle.group in self.minute_counts_by_group:
        #     self.minute_counts_by_group[rle.group] = {}
        # if minute_str not in self.minute_counts_by_group[rle.group]:
        #     self.minute_counts_by_group[rle.group][minute_str] = 0
        # self.minute_counts_by_group[rle.group][minute_str] = self.minute_counts_by_group[rle.group][minute_str] + 1

        # Calc the datetime millisecond timestamps that the request is active
        # for i in range(rle.duration):
        #     ts = (rle.timestamp - datetime.timedelta(milliseconds = i)).isoformat()
        #     if ts not in self.millisec_counts:
        #         self.millisec_counts[ts] = 0
        #     self.millisec_counts[ts] = self.millisec_counts[ts] + 1

        # for i in range(rle.duration):
        #     ts = (rle.timestamp - datetime.timedelta(milliseconds = i)).isoformat()
        #     data2 = {"ts": ts, "rlegroup": rle.group, "count": 1}
        #     cur.execute("INSERT INTO millis VALUES(:ts, :rlegroup, :count)", data2)
        for i in range(rle.duration):
            data2 = {"timestamp": minute_str, "micros": micros_int + i, "rlegroup": rle.group}
            cur.execute("INSERT INTO millis VALUES(:timestamp, :micros, :rlegroup)", data2)


    def commit(self):
        self.conn.commit()

    def get_stats(self):
        cur = self.conn.cursor()
        requests_row_count = cur.execute("SELECT count(*) FROM requests").fetchone()
        millis_row_count = cur.execute("SELECT count(*) FROM millis").fetchone()
        #millis_row_count = 0
        self.logger.debug("Row Counts: requests: %s, millis: %s", requests_row_count, millis_row_count)
        pass

    def get_requests_per_minute(self, group = None):
        cur = self.conn.cursor()
        query = "SELECT timestamp, COUNT(*) FROM requests GROUP BY timestamp"
        if group is not None:
            query = "SELECT timestamp, COUNT(*) FROM requests WHERE rlegroup = '{}' GROUP BY timestamp".format(group)
        requests_query = cur.execute(query).fetchall()
        self.logger.debug("Per minute SQLite Results: %s", requests_query)
        return requests_query

    def get_requests_per_millisecond(self, group = None):
        cur = self.conn.cursor()
        #query = "SELECT timestamp, micros, COUNT(*) FROM millis GROUP BY timestamp, micros"
        query = "SELECT timestamp, MAX(c) FROM (SELECT timestamp, micros, COUNT(*) as c FROM millis GROUP BY timestamp, micros) GROUP BY timestamp"
        if group is not None:
            #query = "SELECT timestamp, micros, COUNT(*) FROM millis WHERE rlegroup = '{}' GROUP BY timestamp, micros".format(group)
            query = "SELECT timestamp, MAX(c) FROM (SELECT timestamp, micros, COUNT(*) as c FROM millis WHERE rlegroup = '{}' GROUP BY timestamp, micros) GROUP BY timestamp".format(group)
        millis_query = cur.execute(query).fetchall()
        self.logger.debug("concurrent SQLite Results: %s", millis_query)
        return millis_query