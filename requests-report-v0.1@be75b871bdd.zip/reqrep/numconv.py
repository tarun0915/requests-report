#!/usr/bin/env python3

### IMPORTS ###
import logging
import math

### GLOBALS ###

### FUNCTIONS ###

### CLASSES ###
class NumConv:
    units = {
         0: {'multiplier': 10 ** 0, 'prefix': ''},
         1: {'multiplier': 10 ** 0, 'prefix': ''},
         2: {'multiplier': 10 ** 0, 'prefix': ''},
         3: {'multiplier': 10 ** 3, 'prefix': 'k'},
         4: {'multiplier': 10 ** 3, 'prefix': 'k'},
         5: {'multiplier': 10 ** 3, 'prefix': 'k'},
         6: {'multiplier': 10 ** 6, 'prefix': 'M'},
         7: {'multiplier': 10 ** 6, 'prefix': 'M'},
         8: {'multiplier': 10 ** 6, 'prefix': 'M'},
         9: {'multiplier': 10 ** 9, 'prefix': 'G'},
        10: {'multiplier': 10 ** 9, 'prefix': 'G'},
        11: {'multiplier': 10 ** 9, 'prefix': 'G'},
        12: {'multiplier': 10 ** 12, 'prefix': 'T'},
        13: {'multiplier': 10 ** 12, 'prefix': 'T'},
        14: {'multiplier': 10 ** 12, 'prefix': 'T'},
        15: {'multiplier': 10 ** 15, 'prefix': 'P'},
        16: {'multiplier': 10 ** 15, 'prefix': 'P'},
        17: {'multiplier': 10 ** 15, 'prefix': 'P'},
        18: {'multiplier': 10 ** 18, 'prefix': 'E'},
    }
    units_i = {
         0: {'multiplier': 1, 'prefix': ''},
         1: {'multiplier': 1, 'prefix': ''},
         2: {'multiplier': 1, 'prefix': ''},
         3: {'multiplier': 1024, 'prefix': 'ki'},
         4: {'multiplier': 1024, 'prefix': 'ki'},
         5: {'multiplier': 1024, 'prefix': 'ki'},
         6: {'multiplier': 1024 * 1024, 'prefix': 'Mi'},
         7: {'multiplier': 1024 * 1024, 'prefix': 'Mi'},
         8: {'multiplier': 1024 * 1024, 'prefix': 'Mi'},
         9: {'multiplier': 1024 * 1024 * 1024, 'prefix': 'Gi'},
        10: {'multiplier': 1024 * 1024 * 1024, 'prefix': 'Gi'},
        11: {'multiplier': 1024 * 1024 * 1024, 'prefix': 'Gi'},
        12: {'multiplier': 1024 * 1024 * 1024 * 1024, 'prefix': 'Ti'},
        13: {'multiplier': 1024 * 1024 * 1024 * 1024, 'prefix': 'Ti'},
        14: {'multiplier': 1024 * 1024 * 1024 * 1024, 'prefix': 'Ti'},
        15: {'multiplier': 1024 * 1024 * 1024 * 1024 * 1024, 'prefix': 'Pi'},
        16: {'multiplier': 1024 * 1024 * 1024 * 1024 * 1024, 'prefix': 'Pi'},
        17: {'multiplier': 1024 * 1024 * 1024 * 1024 * 1024, 'prefix': 'Pi'},
        18: {'multiplier': 1024 * 1024 * 1024 * 1024 * 1024 * 1024, 'prefix': 'Ei'},
    }
    def __init__(self, number):
        self.logger = logging.getLogger(type(self).__name__)
        self.number = number
        self.exponent = 0 if self.number == 0 else int(math.log10(self.number))

    @property
    def number_prefix(self):
        if self.exponent > 18:
            return "{:.1f} {}".format(self.number / self.units[18]['multiplier'], self.units[18]['prefix'])
        elif self.exponent > 0:
            return "{:.1f} {}".format(self.number / self.units[self.exponent]['multiplier'], self.units[self.exponent]['prefix'])
        else:
            return "{}".format(self.number)

    @property
    def number_prefix_i(self):
        if self.exponent > 18:
            return "{:.1f} {}".format(self.number / self.units_i[18]['multiplier'], self.units_i[18]['prefix'])
        elif self.exponent > 0:
            return "{:.1f} {}".format(self.number / self.units_i[self.exponent]['multiplier'], self.units_i[self.exponent]['prefix'])
        else:
            return "{}".format(self.number)
