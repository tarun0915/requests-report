#!/usr/bin/env python3

### IMPORTS ###
import logging

### GLOBALS ###

### FUNCTIONS ###
# The data format is similar to graph data, a dictionary with an "axis" list and multiple value lists.
# { "axis": [x_values],
#   "transfer_up": [y_values],
#   "transfer_down": [y_values] }
def genCSV(filename, data):
    logging.debug("genCSV filename: %s, data: %s", filename, data)
    data_keys = list(data.keys())
    data_keys.remove("axis")
    logging.debug("genCSV data_keys: %s", data_keys)
    # Remove any empty data sets
    # Note: Have to copy the list data_keys or the for loop has issues.
    for key in list(data_keys):
        logging.debug("  key: %s, data: %s", key, data[key])
        if data[key] is None:
            data_keys.remove(key)
    logging.debug("genCSV data_keys: %s", data_keys)
    with open(filename, 'w', encoding="utf-8") as csv_file:
        csv_file.write("datetime")
        for i in data_keys:
            csv_file.write(",{}".format(i))
        csv_file.write("\n")
        for i in range(len(data["axis"])):
            csv_file.write(data["axis"][i])
            for j in data_keys:
                csv_file.write(",{}".format(data[j][i]))
            csv_file.write("\n")

### CLASSES ###
