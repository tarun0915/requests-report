#!/usr/bin/env python3

### IMPORTS ###
import gzip
import hashlib
import logging
import tarfile
import zipfile

from .bundle import BundleType
from .requestlogentry import RequestLogEntrySeven, RequestLogEntrySix

### GLOBALS ###

### FUNCTIONS ###

### CLASSES ###
class FileDeDuper:
    def __init__(self):
        self.logger = logging.getLogger(type(self).__name__)
        self.file_count = 0
        self.files = {}

    def is_dup(self, group, logname):
        self.file_count = self.file_count + 1
        ident = "{}+{}".format(group, logname)
        if ident not in self.files:
            self.files[ident] = 1
            return False
        self.files[ident] = self.files[ident] + 1
        return True

    def get_stats(self):
        return "Total Files: {}, Unique Files: {}".format(self.file_count, len(self.files))


class LineDeDuper:
    def __init__(self):
        self.logger = logging.getLogger(type(self).__name__)
        self.line_count = 0
        self.lines = {}
        self.callbacks = []

    def add_callback(self, cb):
        self.callbacks.append(cb)

    def add_line(self, group, name, line):
        self.line_count = self.line_count + 1
        # NOTE: Using a hash is much more memory efficient than using the entire string, though it still takes a ton of
        #       memory.
        ident = hashlib.sha1("{}+{}".format(group, line).encode('utf-8')).hexdigest()
        if ident in self.lines:
            self.lines[ident] = self.lines[ident] + 1
        else:
            self.lines[ident] = 1
            for cb in self.callbacks:
                cb(group, name, line)

    def get_stats(self):
        return "Total Lines: {}, Unique Lines: {}".format(self.line_count, len(self.lines))

class BundleWalker:
    TBF_NAMES = [
        "artifactory-request.",
        "./artifactory-request.",
        "archived/artifactory-request.",
        "./archived/artifactory-request.",
    ]

    def __init__(self, filededup = False, linededup = False):
        self.logger = logging.getLogger(type(self).__name__)
        self.filededup = filededup
        self.linededup = linededup
        if self.filededup:
            self.fd = FileDeDuper()
        if self.linededup:
            self.ld = LineDeDuper()
            # FIXME: This should support both version 6 and 7
            self.ld.add_callback(self._process_line_seven)
        self.callbacks = []

    def add_callback(self, cb):
        self.callbacks.append(cb)

    def walk_bundle(self, bundle):
        self.logger.info("Walking Bundle: %s", bundle)
        if bundle.type == BundleType.TARBALL:
            self._process_bundle_tarball(bundle)
        elif bundle.type == BundleType.SUPPORT:
            self._process_bundle_support(bundle)
        elif bundle.type == BundleType.LOG:
            self._process_bundle_log(bundle)
        elif bundle.type == BundleType.LOGGZ:
            self._process_bundle_loggz(bundle)
        else:
            self.logger.warning("Unknown Bundle Type! Skipping.")

    def _process_bundle_tarball(self, bundle):
        # Open tarball
        # FIXME: Add some error handling in case of corruption (e.g. truncated files).
        with tarfile.open(bundle.get_path(), 'r:gz') as tb:
            # Extract log files
            # - artifactory-request.log
            # - archived/artifactory-request.*.log
            # - archived/artifactory-request.*.log.gz
            # Parse logs into RequestLogEntry objects
            # NOTE: Due to Mac computers having an odd behavior with their tar command, the paths are specifically matched.
            for tbf_name in tb.getnames():
                self.logger.info("  Evaluating: %s", tbf_name)
                tbf_content_lines = []
                if "artifactory-request.log" == tbf_name:
                    # This matches the "artifactory-request.log" at the root of the tarball
                    # FIXME: Need to add a bundle file name to the dedup as this will trigger for each bundle in a group.
                    if self.filededup and self.fd.is_dup(bundle.group, tbf_name):
                        self.logger.debug("Skipping duplicate log file")
                        continue  # Skip this file as it's a duplicate
                    tbf_content_lines = tb.extractfile(tbf_name).readlines()
                if "archived/artifactory-request." in tbf_name:
                    tbf_content_lines = []
                    if self.filededup and self.fd.is_dup(bundle.group, tbf_name):
                        self.logger.debug("Skipping duplicate log file")
                        continue  # Skip this file as it's a duplicate
                    if tbf_name[-4:] == ".log":
                        tbf_content_lines = tb.extractfile(tbf_name).readlines()
                    elif tbf_name[-7:] == ".log.gz":
                        # FIXME: Add some error handling in case of corruption (e.g. truncated files).
                        tbf_content_lines = gzip.GzipFile(fileobj = tb.extractfile(tbf_name)).readlines()
                self._process_lines_seven(bundle, tbf_content_lines)
        if self.filededup:
            self.logger.debug("File Dedup Stats: %s", self.fd.get_stats())
        if self.linededup:
            self.logger.debug("Line Dedup Stats: %s", self.ld.get_stats())

    def _process_bundle_support(self, bundle):
        # Open ZIP file
        # FIXME: Add some error handling in case of corruption (e.g. truncated files).
        self.logger.info("Processing Support Bundle: %s", bundle.get_path())
        with zipfile.ZipFile(bundle.get_path(), 'r') as sb:
            # Support bundles contain ZIP files internally, one for each node of the JPD
            # Find and open each of the internal ZIP files
            for sb_info in sb.infolist():
                self.logger.debug("Checking sb_info.filename: %s", sb_info.filename)
                #if sb_info.filename[:12] == "artifactory/" and sb_info.filename[-4:] == ".zip":
                if "artifactory/" in sb_info.filename and sb_info.filename[-4:] == ".zip":
                    self.logger.info("Evaluating SB INFO: %s", sb_info.filename)
                    with zipfile.ZipFile(sb.open(sb_info, 'r')) as sbi:
                        for sbi_info in sbi.infolist():
                            self.logger.debug("Checking sbi_info.filename: %s", sbi_info.filename)
                            if "artifactory/logs/" in sbi_info.filename:
                                if "artifactory-request." in sbi_info.filename:
                                    # NOTE: Artifactory Version 7.* Support Bundle Request Log
                                    sbif_content_lines = []
                                    self.logger.info("  Version 7.* Log File in Internal ZIP File: %s", sbi_info.filename)
                                    if self.filededup and self.fd.is_dup(bundle.group, sbi_info.filename):
                                        self.logger.debug("Skipping duplicate log file")
                                        continue  # Skip this file as it's a duplicate
                                    if sbi_info.filename[-4:] == ".log":
                                        with sbi.open(sbi_info, 'r') as sbif:
                                            sbif_content_lines = sbif.readlines()
                                    elif sbi_info.filename[-7:] == ".log.gz":
                                        with sbi.open(sbi_info, 'r') as sbif:
                                            # FIXME: Add some error handling in case of corruption (e.g. truncated files).
                                            sbif_content_lines = gzip.GzipFile(fileobj = sbif).readlines()
                                    self._process_lines_seven(bundle, sbif_content_lines)
                                if "/request." in sbi_info.filename:
                                    # NOTE: Artifactory Version 6.* Support Bundle Request Log
                                    sbif_content_lines = []
                                    self.logger.info("  Version 6.* Log File in Internal ZIP File: %s", sbi_info.filename)
                                    if self.filededup and self.fd.is_dup(bundle.group, sbi_info.filename):
                                        self.logger.debug("Skipping duplicate log file")
                                        continue  # Skip this file as it's a duplicate
                                    if sbi_info.filename[-4:] == ".log":
                                        with sbi.open(sbi_info, 'r') as sbif:
                                            sbif_content_lines = sbif.readlines()
                                    self._process_lines_six(bundle, sbif_content_lines)
        if self.filededup:
            self.logger.debug("File Dedup Stats: %s", self.fd.get_stats())
        if self.linededup:
            self.logger.debug("Line Dedup Stats: %s", self.ld.get_stats())

    def _process_bundle_log(self, bundle):
        # Verify log file name as
        # - artifactory-request.*.log
        # Parse logs into RequestLogEntry objects
        self.logger.info("  Evaluating: %s, group: %s", bundle.get_path(), bundle.group)
        tbf_content_lines = []
        if "artifactory-request." in bundle.get_path():
            if self.filededup and self.fd.is_dup(bundle.group, bundle.get_path()):
                self.logger.debug("Skipping duplicate log file")
            else:
                with open(bundle.get_path(), 'r', encoding="utf-8") as file:
                    for line in file.readlines():
                        tbf_content_lines.append(line.encode("utf-8"))
        self._process_lines_seven(bundle, tbf_content_lines)
        if self.filededup:
            self.logger.debug("File Dedup Stats: %s", self.fd.get_stats())
        if self.linededup:
            self.logger.debug("Line Dedup Stats: %s", self.ld.get_stats())

    def _process_bundle_loggz(self, bundle):
        # Verify log file name as
        # - artifactory-request.*.log.gz
        # Parse logs into RequestLogEntry objects
        self.logger.info("  Evaluating: %s, group: %s", bundle.get_path(), bundle.group)
        tbf_content_lines = []
        if "artifactory-request" in bundle.get_path():
            if self.filededup and self.fd.is_dup(bundle.group, bundle.get_path()):
                self.logger.debug("Skipping duplicate log file")
            else:
                tbf_content_lines = gzip.GzipFile(bundle.get_path()).readlines()
        self._process_lines_seven(bundle, tbf_content_lines)
        if self.filededup:
            self.logger.debug("File Dedup Stats: %s", self.fd.get_stats())
        if self.linededup:
            self.logger.debug("Line Dedup Stats: %s", self.ld.get_stats())

    def _process_lines_seven(self, bundle, lines):
        self.logger.info("V7 Processing %d lines", len(lines))
        cb = self._process_line_seven
        if self.linededup:
            cb = self.ld.add_line
        for tbf_line in lines:
            tmp_line = tbf_line.decode('utf-8')
            if tmp_line[0:3] == "dt.":
                # Log has been munged by the dynatrace functionality in Artifactory
                cb = self._process_line_seven_dynatrace
            cb(bundle.group, bundle.name, tmp_line)

    def _process_line_seven(self, group, name, line):
        #self.logger.debug("V7 Processing group: %s, name: %s, line: %s", group, name, line)
        try:
            rle = RequestLogEntrySeven(group, name, line)
            for cb in self.callbacks:
                cb(rle)
        except Exception as ex:
            self.logger.warning("Unable to process log line: %s", ex)

    def _process_line_seven_dynatrace(self, group, name, line):
        #self.logger.debug("V7 DynaTrace Processing group: %s, name: %s, line: '%s'", group, name, line)
        # Decode the DynaTrace version of the log line
        # Here's some examples of the dynatrace logs:
        #    dt.trace_sampled: true, dt.trace_id: 3d1d00b3a0d8b0ced7a0649e5b73e97b, dt.entity.process_group_instance: , dt.span_id: e1ceecc3198c7616, dt.entity.host:  2023-12-14T22:46:39.048Z|5b104cab3960fa0|127.0.0.1|non_authenticated_user|POST|/api/system/gateway/openid/auth/jfxana@01fe47p8059x314yf8w200tka4|200|38|0|66|Go-http-client/1.1
        #    dt.trace_sampled: true, dt.trace_id: a8aa4a4bd60739c77d78e907363c0b68, dt.entity.process_group_instance: , dt.span_id: a9517755c80b3964, dt.entity.host:  2023-12-14T22:46:39.089Z|531e591632185b92|127.0.0.1|non_authenticated_user|POST|/api/system/gateway/openid/auth/jfxpst@01fe47p805prm4x1jpjm3th2hh|200|38|0|109|Go-http-client/1.1
        #    dt.trace_sampled: true, dt.trace_id: 6cf784eea0c1b339c2d2893f7a865e6a, dt.entity.process_group_instance: , dt.span_id: 04687b486a7c9c0a, dt.entity.host:  2023-12-14T22:46:39.089Z|7b799085f536d1ff|127.0.0.1|non_authenticated_user|POST|/api/system/gateway/openid/auth/jfxr@01fe47p805g4zymydp10ypjxph|200|38|0|107|Go-http-client/1.1
        # As can be seen in the line, the actual log line is contained, so the rest just needs to be stripped off.
        dt_chunks = line.split(',')
        #self.logger.debug("  dt_chunks: %s", dt_chunks)
        for chunk in dt_chunks:
            if chunk[0:18] == " dt.entity.host:  ":
                self._process_line_seven(group, name, chunk[18:])

    def _process_lines_six(self, bundle, lines):
        self.logger.info("V6 Processing %d lines", len(lines))
        cb = self._process_line_six
        if self.linededup:
            cb = self.ld.add_line
        for tbf_line in lines:
            cb(bundle.group, bundle.name, tbf_line.decode('utf-8'))

    def _process_line_six(self, group, name, line):
        #self.logger.debug("V6 Processing group: %s, name: %s, line: %s", group, name, line)
        try:
            rle = RequestLogEntrySix(group, name, line)
            for cb in self.callbacks:
                cb(rle)
        except Exception as ex:
            self.logger.warning("Unable to process log line: %s", ex)
