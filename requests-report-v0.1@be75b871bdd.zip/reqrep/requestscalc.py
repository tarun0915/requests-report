#!/usr/bin/env python3

### IMPORTS ###
import datetime
import logging
import sqlite3

### GLOBALS ###

### FUNCTIONS ###

### CLASSES ###
class RequestsCalc:
    def __init__(self):
        self.logger = logging.getLogger(type(self).__name__)
        self.request_counts = {"total": 0, "upload": 0, "download": 0}
        self.minute_counts = {}
        self.minute_counts_by_group = {}
        self.hour_peaks = {}
        self.hour_peaks_by_group = {}
        self.day_peaks = {}
        self.day_peaks_by_group = {}

    def add_log_entry(self, rle):
        self.request_counts["total"] += 1
        if rle.method in ["PUT", "POST"]:
            self.request_counts["upload"] += 1
        else:
            self.request_counts["download"] += 1
        # Calc the datetime timestamps that the request occurred
        minute_str = rle.timestamp.strftime('%Y-%m-%d %H:%M')
        hour_str = rle.timestamp.strftime('%Y-%m-%d %H:00')
        day_str = rle.timestamp.strftime('%Y-%m-%d 12:00')

        if minute_str not in self.minute_counts:
            self.minute_counts[minute_str] = {"total": 0, "upload": 0, "download": 0}
        self.minute_counts[minute_str]["total"] += 1
        if rle.method in ["PUT", "POST"]:
            self.minute_counts[minute_str]["upload"] += 1
        else:
            self.minute_counts[minute_str]["download"] += 1

        if hour_str not in self.hour_peaks:
            self.hour_peaks[hour_str] = {"total": 0, "upload": 0, "download": 0}
        if self.minute_counts[minute_str]["total"] > self.hour_peaks[hour_str]["total"]:
            self.hour_peaks[hour_str]["total"] = self.minute_counts[minute_str]["total"]
        if self.minute_counts[minute_str]["upload"] > self.hour_peaks[hour_str]["upload"]:
            self.hour_peaks[hour_str]["upload"] = self.minute_counts[minute_str]["upload"]
        if self.minute_counts[minute_str]["download"] > self.hour_peaks[hour_str]["download"]:
            self.hour_peaks[hour_str]["download"] = self.minute_counts[minute_str]["download"]

        if day_str not in self.day_peaks:
            self.day_peaks[day_str] = {"total": 0, "upload": 0, "download": 0}
        if self.minute_counts[minute_str]["total"] > self.day_peaks[day_str]["total"]:
            self.day_peaks[day_str]["total"] = self.minute_counts[minute_str]["total"]
        if self.minute_counts[minute_str]["upload"] > self.day_peaks[day_str]["upload"]:
            self.day_peaks[day_str]["upload"] = self.minute_counts[minute_str]["upload"]
        if self.minute_counts[minute_str]["download"] > self.day_peaks[day_str]["download"]:
            self.day_peaks[day_str]["download"] = self.minute_counts[minute_str]["download"]

        if rle.group not in self.minute_counts_by_group:
            #self.logger.debug("Adding group to minute_counts_by_group: %s", rle.group)
            self.minute_counts_by_group[rle.group] = {}
        if minute_str not in self.minute_counts_by_group[rle.group]:
            #self.logger.debug("Adding minute_str: %s to minute_counts_by_group: %s", minute_str, rle.group)
            self.minute_counts_by_group[rle.group][minute_str] = {"total": 0, "upload": 0, "download": 0}
        self.minute_counts_by_group[rle.group][minute_str]["total"] += 1
        if rle.method in ["PUT", "POST"]:
            self.minute_counts_by_group[rle.group][minute_str]["upload"] += 1
        else:
            self.minute_counts_by_group[rle.group][minute_str]["download"] += 1

        if rle.group not in self.hour_peaks_by_group:
            self.hour_peaks_by_group[rle.group] = {}
        if hour_str not in self.hour_peaks_by_group[rle.group]:
            self.hour_peaks_by_group[rle.group][hour_str] = {"total": 0, "upload": 0, "download": 0}
        if self.hour_peaks_by_group[rle.group][hour_str]["total"] < self.minute_counts_by_group[rle.group][minute_str]["total"]:
            self.hour_peaks_by_group[rle.group][hour_str]["total"] = self.minute_counts_by_group[rle.group][minute_str]["total"]
        if self.hour_peaks_by_group[rle.group][hour_str]["upload"] < self.minute_counts_by_group[rle.group][minute_str]["upload"]:
            self.hour_peaks_by_group[rle.group][hour_str]["upload"] = self.minute_counts_by_group[rle.group][minute_str]["upload"]
        if self.hour_peaks_by_group[rle.group][hour_str]["download"] < self.minute_counts_by_group[rle.group][minute_str]["download"]:
            self.hour_peaks_by_group[rle.group][hour_str]["download"] = self.minute_counts_by_group[rle.group][minute_str]["download"]

        if rle.group not in self.day_peaks_by_group:
            self.day_peaks_by_group[rle.group] = {}
        if day_str not in self.day_peaks_by_group[rle.group]:
            self.day_peaks_by_group[rle.group][day_str] = {"total": 0, "upload": 0, "download": 0}
        if self.day_peaks_by_group[rle.group][day_str]["total"] < self.minute_counts_by_group[rle.group][minute_str]["total"]:
            self.day_peaks_by_group[rle.group][day_str]["total"] = self.minute_counts_by_group[rle.group][minute_str]["total"]
        if self.day_peaks_by_group[rle.group][day_str]["upload"] < self.minute_counts_by_group[rle.group][minute_str]["upload"]:
            self.day_peaks_by_group[rle.group][day_str]["upload"] = self.minute_counts_by_group[rle.group][minute_str]["upload"]
        if self.day_peaks_by_group[rle.group][day_str]["download"] < self.minute_counts_by_group[rle.group][minute_str]["download"]:
            self.day_peaks_by_group[rle.group][day_str]["download"] = self.minute_counts_by_group[rle.group][minute_str]["download"]

    def get_stats(self):
        self.logger.debug("Row Counts: requests: %s, rows: %s", self.request_counts, len(self.minute_counts))
        pass

    def get_requests_per_minute(self, group = None):
        self.logger.debug("Group Name: %s", group)
        if group is not None:
            self.logger.debug("group keys: %s", self.minute_counts_by_group.keys())
            return self.minute_counts_by_group[group]
        return self.minute_counts

    def get_hour_peaks(self, group = None):
        if group is not None:
            return self.hour_peaks_by_group[group]
        return self.hour_peaks

    def get_day_peaks(self, group = None):
        if group is not None:
            return self.day_peaks_by_group[group]
        return self.day_peaks
